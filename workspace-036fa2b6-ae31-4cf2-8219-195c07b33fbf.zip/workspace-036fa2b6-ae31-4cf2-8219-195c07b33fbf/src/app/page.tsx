'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useAdhwa, useHasMounted } from '@/lib/adhwa/store'
import { BackgroundFX } from '@/components/adhwa/BackgroundFX'
import { HeartBurstLayer } from '@/components/adhwa/HeartBurstLayer'
import { WelcomeGate } from '@/components/adhwa/WelcomeGate'
import { TopBar } from '@/components/adhwa/TopBar'
import { Nav } from '@/components/adhwa/Nav'
import { Hero } from '@/components/adhwa/Hero'
import { Gallery } from '@/components/adhwa/Gallery'
import { Reasons } from '@/components/adhwa/Reasons'
import { LoveCounter } from '@/components/adhwa/LoveCounter'
import { Letters } from '@/components/adhwa/Letters'
import { Quiz } from '@/components/adhwa/Quiz'
import { GiftBox } from '@/components/adhwa/GiftBox'
import { MissYou } from '@/components/adhwa/MissYou'
import { Future } from '@/components/adhwa/Future'
import { Mood } from '@/components/adhwa/Mood'
import { LoveSong } from '@/components/adhwa/LoveSong'
import { SecretPage } from '@/components/adhwa/SecretPage'
import { FinalMessage } from '@/components/adhwa/FinalMessage'
import { AdminPanel } from '@/components/adhwa/AdminPanel'

function Splash() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-[#FFE9F1] to-[#FFD6E4]">
      <motion.div
        className="text-center"
        animate={{ scale: [1, 1.1, 1] }}
        transition={{ duration: 1.2, repeat: Infinity }}
      >
        <p className="text-6xl">💗</p>
        <p className="font-script mt-3 text-2xl text-rose-600">menyiapkan dunia kecil...</p>
      </motion.div>
    </div>
  )
}

export default function Home() {
  const mounted = useHasMounted()
  const hydrateMedia = useAdhwa((s) => s.hydrateMedia)
  const mediaReady = useAdhwa((s) => s.mediaReady)
  const siteTitle = useAdhwa((s) => s.data.siteTitle)
  const herName = useAdhwa((s) => s.data.herName)
  const [entered, setEntered] = useState(false)

  useEffect(() => {
    void hydrateMedia()
  }, [hydrateMedia])

  if (!mounted || !mediaReady) return <Splash />

  return (
    <div className="relative min-h-screen">
      <BackgroundFX />
      <HeartBurstLayer />
      <WelcomeGate onDone={() => setEntered(true)} />

      <AnimatePresence>
        {entered && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
          >
            <TopBar />
          </motion.div>
        )}
      </AnimatePresence>

      <main className="relative z-10 flex flex-col">
        <Hero />
        <Gallery />
        <Reasons />
        <LoveCounter />
        <Letters />
        <Quiz />
        <GiftBox />
        <MissYou />
        <Future />
        <Mood />
        <LoveSong />
        <SecretPage />
        <FinalMessage />

        <footer className="relative z-10 mt-auto pb-28 pt-6 text-center">
          <div className="mb-3 flex items-center justify-center gap-2 text-pink-300">
            <span className="h-px w-16 bg-gradient-to-r from-transparent to-pink-300" />
            <span className="anim-heartbeat text-lg">💗</span>
            <span className="h-px w-16 bg-gradient-to-l from-transparent to-pink-300" />
          </div>
          <p className="font-script text-xl text-rose-600">{siteTitle} 💗</p>
          <p className="mt-1 text-xs text-rose-500/70">
            dibuat dengan penuh sayang oleh pacarmu — khusus untuk {herName}
          </p>
          <p className="mt-2 text-[10px] text-rose-400/60">
            foto, tulisan, dan lagu tersimpan aman di browser ini · tekan 🔧 untuk mengubah semuanya
          </p>
        </footer>
      </main>

      {entered && <Nav />}
      <AdminPanel />
    </div>
  )
}
