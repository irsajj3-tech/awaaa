import type { Metadata, Viewport } from "next";
import { Quicksand, Dancing_Script, Baloo_2 } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const quicksand = Quicksand({
  variable: "--font-quicksand",
  subsets: ["latin"],
});

const dancing = Dancing_Script({
  variable: "--font-dancing",
  subsets: ["latin"],
});

const baloo = Baloo_2({
  variable: "--font-baloo",
  subsets: ["latin"],
});

const HEART_ICON =
  "data:image/svg+xml," +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text y="0.9em" font-size="90">💗</text></svg>`
  );

export const metadata: Metadata = {
  title: "A Little World For Adhwa 💗",
  description:
    "Sebuah dunia kecil yang dibuat khusus untuk Adhwa — penuh hati, bunga, surat cinta, dan sayang yang nggak habis-habisnya.",
  icons: { icon: HEART_ICON },
};

export const viewport: Viewport = {
  themeColor: "#FFD6E4",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body
        className={`${quicksand.variable} ${dancing.variable} ${baloo.variable} font-sans antialiased text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
