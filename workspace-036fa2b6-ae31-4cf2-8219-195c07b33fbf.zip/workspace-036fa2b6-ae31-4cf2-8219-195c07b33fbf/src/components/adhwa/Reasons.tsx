'use client'

import { useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Section } from './Section'
import { CuteButton, SoftButton } from './CuteButton'
import { useAdhwa } from '@/lib/adhwa/store'
import { burstFromElement } from '@/lib/adhwa/burst'
import { useToast } from '@/hooks/use-toast'

export function Reasons() {
  const reasons = useAdhwa((s) => s.data.reasons)
  const bag = useRef<number[]>([])
  const [current, setCurrent] = useState<number | null>(null)
  const [opened, setOpened] = useState(0)
  const { toast } = useToast()

  const drawRandom = () => {
    if (bag.current.length === 0) {
      bag.current = Array.from({ length: reasons.length }, (_, i) => i).sort(() => Math.random() - 0.5)
      if (opened >= reasons.length && reasons.length > 0) {
        toast({ title: 'Mabuk cinta! 💗', description: 'Semua 100 alasan sudah dibuka. Kita ulangi lagi ya, biar kamu makin sayang 😆' })
      }
    }
    const idx = bag.current.pop()
    if (idx === undefined) return
    setCurrent(idx)
    setOpened((o) => Math.min(o + 1, reasons.length))
  }

  return (
    <Section
      id="reasons"
      emoji="💗"
      kicker="kalau kamu bosen dibales sayang, buka ini"
      title="100 Reasons Why I Love You"
      sub="Ada 100 alasan kenapa aku jatuh cinta sama kamu. Tekan tombolnya, dan dunia kecil ini bakal kasih satu alasan secara acak."
    >
      <div className="mx-auto max-w-xl">
        <div className="relative min-h-[240px]">
          {/* stacked decorative cards */}
          <div className="glass absolute inset-x-4 top-3 h-full rounded-3xl rotate-2 opacity-60" aria-hidden />
          <div className="glass absolute inset-x-2 top-1.5 h-full rounded-3xl -rotate-1 opacity-80" aria-hidden />

          <AnimatePresence mode="wait">
            <motion.div
              key={current ?? 'start'}
              initial={{ opacity: 0, rotateY: 90, scale: 0.85 }}
              animate={{ opacity: 1, rotateY: 0, scale: 1 }}
              exit={{ opacity: 0, rotateY: -90, scale: 0.85 }}
              transition={{ duration: 0.45, ease: 'easeOut' }}
              className="glass relative flex min-h-[240px] flex-col items-center justify-center rounded-3xl p-8 text-center"
            >
              {current === null ? (
                <>
                  <span className="text-5xl">💌</span>
                  <p className="mt-4 text-sm text-rose-700/80">Ada {reasons.length} kartu cinta menunggu dibuka...</p>
                </>
              ) : (
                <>
                  <span className="rounded-full bg-pink-200/80 px-4 py-1 text-xs font-bold text-rose-700">
                    Alasan #{current + 1}
                  </span>
                  <p className="font-script mt-4 text-2xl leading-relaxed text-rose-900 sm:text-3xl">
                    &ldquo;{reasons[current] ?? '...'}&rdquo;
                  </p>
                </>
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        <div className="mt-6 flex flex-col items-center gap-3">
          <CuteButton size="lg" className="px-8" onClick={(e) => { burstFromElement(e.currentTarget, { count: 14 }); drawRandom(); }}>
            {current === null ? 'Buka Satu Alasan 💌' : 'Lagi, Satu Alasan Lagi! 💖'}
          </CuteButton>
          <p className="text-xs font-semibold text-rose-600/80">Sudah dibuka: {opened} / {reasons.length} 💗</p>
          {current !== null && (
            <SoftButton
              size="sm"
              onClick={() => {
                bag.current = []
                setCurrent(null)
                setOpened(0)
              }}
            >
              ♻️ Mulai Dari Awal
            </SoftButton>
          )}
        </div>
      </div>
    </Section>
  )
}
