'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Section, GlassCard } from './Section'
import { CuteButton, SoftButton } from './CuteButton'
import { useAdhwa } from '@/lib/adhwa/store'
import { burstFromElement, randomBurst } from '@/lib/adhwa/burst'

type Stage = 'intro' | 'play' | 'result'

export function Quiz() {
  const quiz = useAdhwa((s) => s.data.quiz)
  const herName = useAdhwa((s) => s.data.herName)
  const [stage, setStage] = useState<Stage>('intro')
  const [idx, setIdx] = useState(0)
  const [score, setScore] = useState(0)
  const [picked, setPicked] = useState<number | null>(null)
  const [shake, setShake] = useState(false)

  const q = quiz.questions[idx]

  const start = () => {
    setStage('play')
    setIdx(0)
    setScore(0)
    setPicked(null)
  }

  const pick = (i: number, ev: React.MouseEvent<HTMLButtonElement>) => {
    if (picked !== null) return
    setPicked(i)
    if (q && i === q.correct) {
      setScore((s) => s + 1)
      burstFromElement(ev.currentTarget, { count: 12, power: 130 })
    } else {
      setShake(true)
      setTimeout(() => setShake(false), 500)
    }
    setTimeout(() => {
      if (idx + 1 >= quiz.questions.length) {
        setStage('result')
        randomBurst(6, { count: 10 })
      } else {
        setIdx((x) => x + 1)
        setPicked(null)
      }
    }, 800)
  }

  const tier = [...quiz.tiers].sort((a, b) => b.min - a.min).find((t) => score >= t.min) ?? quiz.tiers[0]

  return (
    <Section
      id="quiz"
      emoji="🎀"
      kicker="permainan khusus bucin certified"
      title={quiz.title}
      sub="Jawab 6 pertanyaan super penting ini! Skor kamu akan menentukan gelar bucin se-dunia kecil ini 😆"
    >
      <GlassCard className="mx-auto max-w-xl">
        <AnimatePresence mode="wait">
          {stage === 'intro' && (
            <motion.div
              key="intro"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="text-center"
            >
              <motion.span
                className="inline-block text-6xl"
                animate={{ rotate: [0, -8, 8, 0] }}
                transition={{ duration: 1.8, repeat: Infinity }}
              >
                🎀
              </motion.span>
              <p className="mt-4 text-sm text-rose-700/80">
                Siap uji seberapa bucin kamu sama {herName}? Eh... maksudku seberapa kenal kamu sama dia? 😆
              </p>
              <CuteButton size="lg" className="mt-6 px-8" onClick={start}>
                Mulai Kuisnya! 🎀
              </CuteButton>
            </motion.div>
          )}

          {stage === 'play' && q && (
            <motion.div
              key={`q-${idx}`}
              initial={{ opacity: 0, x: 60 }}
              animate={{ opacity: 1, x: 0, ...(shake ? { x: [0, -10, 10, -6, 6, 0] } : {}) }}
              exit={{ opacity: 0, x: -60 }}
              transition={{ duration: 0.35 }}
            >
              <div className="mb-4 flex items-center justify-center gap-1">
                {quiz.questions.map((_, i) => (
                  <motion.span
                    key={i}
                    animate={{ scale: i === idx ? 1.3 : 1 }}
                    className={`text-lg ${i < idx ? (i <= score ? '💖' : '🤍') : i === idx ? '💗' : '🩷'}`}
                  >
                    {i < idx ? '💖' : i === idx ? '💗' : '🤍'}
                  </motion.span>
                ))}
              </div>
              <p className="text-center text-xs font-bold uppercase tracking-widest text-rose-400">
                Pertanyaan {idx + 1} / {quiz.questions.length}
              </p>
              <h3 className="font-display mt-2 text-center text-xl font-bold text-rose-900 sm:text-2xl">{q.q}</h3>
              <div className="mt-6 grid gap-3">
                {q.options.map((opt, i) => {
                  const isPicked = picked === i
                  const isCorrect = picked !== null && i === q.correct
                  return (
                    <motion.button
                      key={i}
                      onClick={(e) => pick(i, e)}
                      disabled={picked !== null}
                      whileTap={{ scale: 0.96 }}
                      animate={isPicked ? { scale: [1, 1.08, 1] } : {}}
                      className={`rounded-2xl border-2 px-4 py-3 text-left text-sm font-semibold transition-all sm:text-base ${
                        isCorrect
                          ? 'border-pink-400 bg-pink-200/80 text-rose-900 shadow-[0_0_20px_rgba(231,84,128,0.4)]'
                          : isPicked
                            ? 'border-rose-300 bg-rose-100 text-rose-700'
                            : picked !== null
                              ? 'border-pink-100 bg-white/50 text-rose-400'
                              : 'border-pink-200 bg-white/70 text-rose-800 hover:border-pink-300 hover:bg-pink-50 active:scale-95'
                      }`}
                    >
                      <span className="mr-2">{isCorrect ? '✅' : isPicked ? '😅' : '🎀'}</span>
                      {opt}
                    </motion.button>
                  )
                })}
              </div>
            </motion.div>
          )}

          {stage === 'result' && (
            <motion.div
              key="result"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ type: 'spring', stiffness: 200, damping: 15 }}
              className="text-center"
            >
              <motion.span
                className="inline-block text-6xl"
                animate={{ scale: [1, 1.2, 1], rotate: [0, 10, -10, 0] }}
                transition={{ duration: 1.4, repeat: Infinity }}
              >
                {score === quiz.questions.length ? '🏆' : score >= quiz.questions.length / 2 ? '👑' : '🥺'}
              </motion.span>
              <p className="font-display mt-4 text-4xl font-extrabold text-rose-600">
                Skor: {score}/{quiz.questions.length}
              </p>
              <h3 className="font-script mt-3 text-3xl text-rose-800">{tier?.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-rose-700/85">{tier?.text}</p>
              <div className="mt-6 flex flex-wrap justify-center gap-3">
                <CuteButton onClick={start}>Ulangi Kuisnya 🎀</CuteButton>
                <SoftButton
                  onClick={() =>
                    randomBurst(5, { count: 8, emojis: ['💗', '💖', '✨'] })
                  }
                >
                  Lempar Hati ke Aku 💖
                </SoftButton>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </GlassCard>
    </Section>
  )
}
