'use client'

import { burstFromElement } from '@/lib/adhwa/burst'

const ITEMS = [
  { id: 'hero', emoji: '🏠', label: 'Beranda' },
  { id: 'gallery', emoji: '📸', label: 'Galeri' },
  { id: 'reasons', emoji: '💗', label: '100 Alasan' },
  { id: 'counter', emoji: '⏳', label: 'Hitungan' },
  { id: 'letters', emoji: '💌', label: 'Surat' },
  { id: 'quiz', emoji: '🎀', label: 'Kuis' },
  { id: 'gifts', emoji: '🎁', label: 'Hadiah' },
  { id: 'missyou', emoji: '🐻', label: 'Kangen' },
  { id: 'future', emoji: '🌷', label: 'Impian' },
  { id: 'mood', emoji: '💓', label: 'Mood' },
  { id: 'song', emoji: '🎵', label: 'Lagu' },
  { id: 'secret', emoji: '🌹', label: 'Rahasia' },
  { id: 'final', emoji: '📜', label: 'Penutup' },
]

export function Nav() {
  const go = (id: string, el: HTMLElement) => {
    burstFromElement(el, { count: 6, power: 70, size: 14 })
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  return (
    <nav
      aria-label="Navigasi dunia kecil"
      className="glass fixed bottom-3 left-1/2 z-40 flex max-w-[94vw] -translate-x-1/2 items-center gap-1 overflow-x-auto rounded-full px-2 py-1.5 pink-scroll"
      style={{ WebkitOverflowScrolling: 'touch' }}
    >
      {ITEMS.map((it) => (
        <button
          key={it.id}
          onClick={(e) => go(it.id, e.currentTarget)}
          className="group flex min-w-[3.2rem] flex-col items-center rounded-full px-2 py-1 transition-all hover:-translate-y-0.5 hover:bg-pink-100/80 active:scale-90"
          aria-label={it.label}
        >
          <span className="text-xl transition-transform group-hover:scale-125">{it.emoji}</span>
          <span className="text-[9px] font-semibold leading-tight text-rose-700/90">{it.label}</span>
        </button>
      ))}
    </nav>
  )
}
