'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { GlassCard } from './Section'
import { CuteButton } from './CuteButton'
import { useAdhwa } from '@/lib/adhwa/store'
import { randomBurst, burstFromElement } from '@/lib/adhwa/burst'

export function FinalMessage() {
  const final = useAdhwa((s) => s.data.final)
  const herName = useAdhwa((s) => s.data.herName)
  const [celebrate, setCelebrate] = useState(false)

  const celebrateNow = (e: React.MouseEvent<HTMLButtonElement>) => {
    burstFromElement(e.currentTarget, { count: 24, power: 260, size: 26 })
    randomBurst(10, { count: 14, power: 240 })
    setCelebrate(true)
    // extra fireworks waves
    for (let i = 1; i <= 8; i++) {
      setTimeout(() => randomBurst(4, { count: 12, power: 260 }), i * 350)
    }
  }

  return (
    <section id="final" className="relative z-10 mx-auto w-full max-w-4xl scroll-mt-20 px-4 py-16 text-center sm:py-24">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.7 }}
      >
        <p className="font-script text-2xl text-rose-400">penutup dunia kecil ini</p>
        <motion.h2
          className="font-script mt-4 text-3xl font-bold leading-snug text-transparent sm:text-5xl sm:leading-snug"
          style={{
            backgroundImage: 'linear-gradient(90deg,#C9184A,#E75480,#B76E79,#E75480,#C9184A)',
            backgroundSize: '200% 100%',
            WebkitBackgroundClip: 'text',
            backgroundClip: 'text',
          }}
          animate={{ backgroundPosition: ['0% 50%', '200% 50%'] }}
          transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
        >
          &ldquo;{final.title}&rdquo;
        </motion.h2>

        <GlassCard className="mx-auto mt-10 max-w-2xl">
          <p className="text-sm leading-relaxed text-rose-900/90 sm:text-base">{final.message}</p>
          <p className="font-script mt-4 text-xl text-rose-600">
            Terima kasih sudah jadi tokoh utama di dunia kecil ini, {herName} 🤍
          </p>
        </GlassCard>

        <div className="mt-10">
          <CuteButton size="lg" className="anim-heartbeat px-10 py-6 text-lg" onClick={celebrateNow} burstCount={0}>
            {final.btn}
          </CuteButton>
        </div>

        <AnimatePresence>
          {celebrate && (
            <motion.div
              initial={{ opacity: 0, scale: 0.4, rotate: -4 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              exit={{ opacity: 0, scale: 0.6 }}
              transition={{ type: 'spring', stiffness: 240, damping: 12 }}
              className="mt-10"
            >
              <p
                className="font-display text-4xl font-extrabold text-transparent sm:text-6xl"
                style={{
                  backgroundImage: 'linear-gradient(90deg,#E75480,#FF9BC0,#B76E79,#FFC8DD,#E75480)',
                  backgroundSize: '200% 100%',
                  WebkitBackgroundClip: 'text',
                  backgroundClip: 'text',
                }}
              >
                {final.fireworks}
              </p>
              <motion.p
                className="mt-3 text-2xl"
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 1.4, repeat: Infinity }}
              >
                🎆💖✨🌸🎆
              </motion.p>
              <p className="mt-4 text-sm text-rose-600/80">
                kamu resmi jadi orang favoritku — hari ini, besok, dan selamanya 💗
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </section>
  )
}
