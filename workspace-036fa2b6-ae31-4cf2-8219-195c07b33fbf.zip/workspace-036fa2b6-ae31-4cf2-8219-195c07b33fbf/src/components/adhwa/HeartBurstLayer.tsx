'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { BurstDetail, DEFAULT_HEARTS } from '@/lib/adhwa/burst'

interface Piece {
  id: number
  x: number
  y: number
  emoji: string
  dx: number
  dy: number
  rot: number
  scale: number
  dur: number
}

let uid = 0

export function HeartBurstLayer() {
  const [pieces, setPieces] = useState<Piece[]>([])
  const [sparkles, setSparkles] = useState<Piece[]>([])
  const onBurst = useCallback((e: Event) => {
    const d = (e as CustomEvent<BurstDetail>).detail
    const count = Math.min(d.count ?? 12, 30)
    const power = d.power ?? 140
    const base = d.size ?? 24
    const emojis = d.emojis ?? DEFAULT_HEARTS
    const newPieces: Piece[] = Array.from({ length: count }, () => {
      const angle = Math.random() * Math.PI * 2
      const dist = power * (0.4 + Math.random() * 0.8)
      return {
        id: ++uid,
        x: d.x,
        y: d.y,
        emoji: emojis[Math.floor(Math.random() * emojis.length)],
        dx: Math.cos(angle) * dist,
        dy: Math.sin(angle) * dist - 60,
        rot: (Math.random() - 0.5) * 120,
        scale: 0.6 + Math.random() * 1.2,
        dur: 0.9 + Math.random() * 0.7,
      }
    })
    setPieces((prev) => [...prev.slice(-90), ...newPieces])
  }, [])

  useEffect(() => {
    window.addEventListener('adhwa-burst', onBurst)
    // subtle sparkle on every click
    const onClick = (e: MouseEvent) => {
      const id = ++uid
      setSparkles((prev) => [
        ...prev.slice(-20),
        { id, x: e.clientX, y: e.clientY, emoji: '✨', dx: 0, dy: -26, rot: 0, scale: 1, dur: 0.6 },
      ])
    }
    window.addEventListener('click', onClick)
    return () => {
      window.removeEventListener('adhwa-burst', onBurst)
      window.removeEventListener('click', onClick)
    }
  }, [onBurst])

  return (
    <div className="pointer-events-none fixed inset-0 z-[80] overflow-hidden" aria-hidden="true">
      <AnimatePresence>
        {pieces.map((p) => (
          <motion.span
            key={p.id}
            className="absolute select-none"
            style={{ left: p.x, top: p.y, fontSize: 22 * p.scale }}
            initial={{ x: -11, y: -11, opacity: 1, rotate: 0, scale: 0.4 }}
            animate={{ x: p.dx - 11, y: p.dy - 11, opacity: 0, rotate: p.rot, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: p.dur, ease: 'easeOut' }}
            onAnimationComplete={() =>
              setPieces((prev) => prev.filter((pp) => pp.id !== p.id))
            }
          >
            {p.emoji}
          </motion.span>
        ))}
        {sparkles.map((s) => (
          <motion.span
            key={`sp-${s.id}`}
            className="absolute select-none text-base"
            style={{ left: s.x - 8, top: s.y - 8 }}
            initial={{ opacity: 0.9, scale: 0.4, y: 0 }}
            animate={{ opacity: 0, scale: 1.5, y: -26 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.55, ease: 'easeOut' }}
            onAnimationComplete={() =>
              setSparkles((prev) => prev.filter((pp) => pp.id !== s.id))
            }
          >
            {s.emoji}
          </motion.span>
        ))}
      </AnimatePresence>
    </div>
  )
}
