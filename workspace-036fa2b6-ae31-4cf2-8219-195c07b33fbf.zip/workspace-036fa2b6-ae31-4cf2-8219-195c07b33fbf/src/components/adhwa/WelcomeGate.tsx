'use client'

import { useEffect, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useAdhwa } from '@/lib/adhwa/store'
import { burstHearts } from '@/lib/adhwa/burst'
import { CuteButton } from './CuteButton'

export function WelcomeGate({ onDone }: { onDone: () => void }) {
  const data = useAdhwa((s) => s.data)
  const [open, setOpen] = useState(true)
  const [leaving, setLeaving] = useState(false)
  const btnRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : ''
    return () => {
      document.body.style.overflow = ''
    }
  }, [open])

  const handleOpen = () => {
    const r = btnRef.current?.getBoundingClientRect()
    const cx = r ? r.left + r.width / 2 : window.innerWidth / 2
    const cy = r ? r.top + r.height / 2 : window.innerHeight / 2
    burstHearts(cx, cy, { count: 26, power: 220, size: 28 })
    burstHearts(cx, cy - 80, { count: 18, power: 260, size: 24 })
    setTimeout(() => burstHearts(window.innerWidth / 2, window.innerHeight / 3, { count: 20, power: 300 }), 350)
    setLeaving(true)
    setTimeout(() => {
      setOpen(false)
      onDone()
    }, 850)
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[70] flex items-center justify-center overflow-hidden bg-gradient-to-br from-[#FFE9F1] via-[#FFD6E4] to-[#FFC2D6] px-4"
          exit={{ opacity: 0, scale: 1.18, filter: 'blur(10px)' }}
          transition={{ duration: 0.8, ease: 'easeInOut' }}
        >
          {/* decorative floating emojis */}
          {['💗', '🎀', '🌸', '✨', '🦋', '💖', '🌷', '💌'].map((e, i) => (
            <motion.span
              key={i}
              className="pointer-events-none absolute select-none"
              style={{ left: `${8 + ((i * 12) % 84)}%`, top: `${(i * 13) % 80}%`, fontSize: 24 + (i % 3) * 10 }}
              animate={{ y: [0, -18, 0], rotate: [0, 8, -8, 0] }}
              transition={{ duration: 3 + (i % 4), repeat: Infinity, delay: i * 0.4 }}
            >
              {e}
            </motion.span>
          ))}

          <motion.div
            className="glass relative z-10 w-full max-w-md rounded-[2.5rem] px-8 py-10 text-center"
            initial={{ opacity: 0, y: 40, scale: 0.9 }}
            animate={{ opacity: leaving ? 0 : 1, y: leaving ? -30 : 0, scale: leaving ? 1.06 : 1 }}
            transition={{ duration: 0.7, ease: 'easeOut' }}
          >
            <motion.div
              className="mx-auto mb-4 text-6xl"
              animate={{ scale: [1, 1.15, 1], rotate: [0, -6, 6, 0] }}
              transition={{ duration: 1.6, repeat: Infinity }}
            >
              💌
            </motion.div>
            <h1 className="font-script text-4xl font-bold text-rose-600 sm:text-5xl">{data.welcome.title}</h1>
            <p className="mt-4 text-base text-rose-800/80">{data.welcome.sub}</p>
            <div className="mt-8 flex justify-center">
              <CuteButton
                ref={btnRef}
                size="lg"
                burstCount={0}
                onClick={handleOpen}
                className="anim-heartbeat px-8 py-6 text-lg"
              >
                {data.welcome.btn} 🎀
              </CuteButton>
            </div>
            <p className="mt-6 text-xs text-rose-500/70">dibuat dengan 💗 khusus untuk {data.herName}</p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
