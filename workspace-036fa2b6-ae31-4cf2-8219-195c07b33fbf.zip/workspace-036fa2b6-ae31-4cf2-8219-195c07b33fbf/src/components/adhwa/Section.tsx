'use client'

import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'

interface SectionProps {
  id: string
  emoji: string
  kicker: string
  title: string
  sub?: string
  children: React.ReactNode
  className?: string
}

export function Section({ id, emoji, kicker, title, sub, children, className }: SectionProps) {
  return (
    <section id={id} className={cn('relative z-10 mx-auto w-full max-w-5xl scroll-mt-20 px-4 py-12 sm:py-16', className)}>
      <motion.div
        initial={{ opacity: 0, y: 28 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-60px' }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
      >
        <div className="mb-8 text-center">
          <p className="font-script text-2xl text-rose-400">{kicker}</p>
          <h2 className="font-display mt-1 text-3xl font-extrabold text-rose-950 sm:text-4xl">
            <span className="mr-2">{emoji}</span>
            {title}
          </h2>
          {sub ? <p className="mx-auto mt-3 max-w-xl text-sm text-rose-700/80 sm:text-base">{sub}</p> : null}
          <div className="mt-4 flex items-center justify-center gap-2 text-pink-300">
            <span className="h-px w-16 bg-gradient-to-r from-transparent to-pink-300" />
            <span className="anim-heartbeat text-lg">💗</span>
            <span className="h-px w-16 bg-gradient-to-l from-transparent to-pink-300" />
          </div>
        </div>
        {children}
      </motion.div>
    </section>
  )
}

export function GlassCard({
  className,
  children,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        'glass rounded-3xl p-6',
        className
      )}
      {...props}
    >
      {children}
    </div>
  )
}
