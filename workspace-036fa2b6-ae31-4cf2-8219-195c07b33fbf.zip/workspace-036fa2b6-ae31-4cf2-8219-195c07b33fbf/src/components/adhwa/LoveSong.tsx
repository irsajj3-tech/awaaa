'use client'

import { useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { Section, GlassCard } from './Section'
import { CuteButton, SoftButton } from './CuteButton'
import { useAdhwa, useUi } from '@/lib/adhwa/store'
import { music } from '@/lib/adhwa/music'
import { audioToDataUrl } from '@/lib/adhwa/image'
import { burstFromElement } from '@/lib/adhwa/burst'
import { useToast } from '@/hooks/use-toast'

export function LoveSong() {
  const songName = useAdhwa((s) => s.data.songName)
  const herName = useAdhwa((s) => s.data.herName)
  const customSong = useAdhwa((s) => s.media['song'])
  const setMedia = useAdhwa((s) => s.setMedia)
  const update = useAdhwa((s) => s.update)
  const mediaReady = useAdhwa((s) => s.mediaReady)
  const musicOn = useUi((s) => s.musicOn)
  const setMusicOn = useUi((s) => s.setMusicOn)
  const [volume, setVolume] = useState(music.getVolume())
  const [busy, setBusy] = useState(false)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const rafRef = useRef<number>(0)
  const { toast } = useToast()

  // load custom song into engine whenever it changes
  useEffect(() => {
    if (mediaReady) {
      music.setCustom(customSong ?? null)
    }
  }, [customSong, mediaReady])

  // visualizer
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    let t = 0
    const draw = () => {
      const w = (canvas.width = canvas.offsetWidth * 2)
      const h = (canvas.height = canvas.offsetHeight * 2)
      ctx.clearRect(0, 0, w, h)
      const analyser = music.getAnalyser()
      const bars = 32
      const barW = w / bars

      let data: Uint8Array | null = null
      if (analyser && music.playing) {
        data = new Uint8Array(analyser.frequencyBinCount)
        analyser.getByteFrequencyData(data)
      }

      for (let i = 0; i < bars; i++) {
        let level: number
        if (data) {
          level = data[i] / 255
        } else {
          // idle gentle wave
          level = 0.12 + 0.1 * Math.sin(t / 22 + i * 0.55) + 0.06 * Math.sin(t / 9 + i)
          level = Math.max(0.04, level)
        }
        const barH = Math.max(4, level * h * 0.9)
        const grad = ctx.createLinearGradient(0, h, 0, h - barH)
        grad.addColorStop(0, '#F9A8C9')
        grad.addColorStop(1, '#E75480')
        ctx.fillStyle = grad
        ctx.beginPath()
        ctx.roundRect(i * barW + barW * 0.15, h - barH, barW * 0.7, barH, 6)
        ctx.fill()
      }
      t++
      rafRef.current = requestAnimationFrame(draw)
    }
    rafRef.current = requestAnimationFrame(draw)
    return () => cancelAnimationFrame(rafRef.current)
  }, [])

  const togglePlay = async (e: React.MouseEvent<HTMLButtonElement>) => {
    burstFromElement(e.currentTarget, { count: 10, power: 120 })
    const playing = await music.toggle()
    setMusicOn(playing)
  }

  const handleVolume = (v: number[]) => {
    const val = v[0] ?? 0.6
    setVolume(val)
    music.setVolume(val)
  }

  const uploadSong = async (f: File | undefined) => {
    if (!f) return
    setBusy(true)
    try {
      const url = await audioToDataUrl(f)
      await setMedia('song', url)
      update({ songName: f.name.replace(/\.[^.]+$/, '') })
      toast({ title: 'Lagu tersimpan! 🎵', description: 'Tekan play untuk mendengarkan lagu pilihanmu.' })
    } catch {
      toast({ title: 'Gagal memuat lagu 😢', description: 'Coba file audio lain ya.' })
    } finally {
      setBusy(false)
    }
  }

  const resetSong = async () => {
    await setMedia('song', null)
    update({ songName: 'Music Box Cinta (bawaan dunia ini)' })
    toast({ title: 'Kembali ke music box 💗', description: 'Musik bawaan dunia kecil ini aktif lagi.' })
  }

  return (
    <Section
      id="song"
      emoji="🎵"
      kicker="lagu yang selalu kubunyikan buat kamu"
      title="Our Love Song"
      sub="Musik nggak akan nyala sendiri — tekan play dulu ya. Kamu juga bisa ganti dengan lagu favorit kalian."
    >
      <GlassCard className="mx-auto max-w-xl">
        <div className="flex items-center gap-5">
          <motion.div
            className="relative flex h-24 w-24 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-pink-400 to-rose-500 shadow-[0_10px_30px_rgba(231,84,128,0.4)]"
            animate={{ rotate: musicOn ? 360 : 0 }}
            transition={{ duration: 6, repeat: musicOn ? Infinity : 0, ease: 'linear' }}
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-white/90 text-xl">💗</span>
            <motion.span
              className="absolute -inset-2 rounded-full border-2 border-pink-300/60"
              animate={musicOn ? { scale: [1, 1.15, 1] } : { scale: 1 }}
              transition={{ duration: 1.2, repeat: musicOn ? Infinity : 0 }}
            />
          </motion.div>
          <div className="min-w-0 flex-1">
            <p className="font-script truncate text-2xl text-rose-800">{songName}</p>
            <p className="mt-1 text-xs text-rose-500/80">untuk: {herName} ♡ — dari aku</p>
            <p className="mt-2 inline-flex items-center gap-1 rounded-full bg-pink-100 px-3 py-1 text-[11px] font-bold text-rose-600">
              {customSong && mediaReady ? '🎵 Lagu pilihanmu' : '🎼 Music box bawaan'}
            </p>
          </div>
        </div>

        <canvas ref={canvasRef} className="mt-6 h-16 w-full" aria-hidden="true" />

        <div className="mt-4 flex flex-wrap items-center gap-4">
          <CuteButton size="lg" className="h-14 w-14 !p-0 text-2xl" onClick={(e) => void togglePlay(e)} aria-label={musicOn ? 'Pause musik' : 'Play musik'}>
            {musicOn ? '⏸' : '▶'}
          </CuteButton>
          <div className="flex flex-1 items-center gap-3 min-w-[180px]">
            <span className="text-lg" aria-hidden>🔊</span>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={volume}
              onChange={(e) => handleVolume([Number(e.target.value)])}
              className="pink-range w-full"
              aria-label="Volume musik"
            />
            <span className="w-10 text-right text-xs font-bold text-rose-500">{Math.round(volume * 100)}%</span>
          </div>
        </div>

        <div className="mt-6 flex flex-wrap items-center gap-3 border-t border-pink-100 pt-5">
          <label>
            <input
              type="file"
              accept="audio/*"
              className="hidden"
              onChange={(e) => {
                void uploadSong(e.target.files?.[0])
                e.target.value = ''
              }}
            />
            <span className="inline-flex h-10 cursor-pointer items-center justify-center rounded-full border border-pink-300 bg-white/80 px-5 text-sm font-bold text-rose-600 transition hover:bg-pink-50 active:scale-95">
              {busy ? 'Memuat lagu... ⏳' : '📤 Ganti Lagu Sendiri'}
            </span>
          </label>
          <SoftButton size="sm" onClick={() => void resetSong()}>
            ♪ Pakai Music Box Bawaan
          </SoftButton>
        </div>
        <p className="mt-3 text-[11px] leading-relaxed text-rose-500/70">
          Musik bawaan adalah music box lembut yang dibuat langsung di browser (bebas royalti). Kalau kamu upload lagu sendiri,
          lagu itu tersimpan aman di browser ini dan tidak akan hilang saat halaman di-refresh.
        </p>
      </GlassCard>
    </Section>
  )
}
