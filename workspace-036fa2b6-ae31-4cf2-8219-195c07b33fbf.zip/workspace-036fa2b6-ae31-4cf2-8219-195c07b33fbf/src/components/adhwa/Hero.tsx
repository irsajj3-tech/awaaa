'use client'

import { motion } from 'framer-motion'
import { GlassCard } from './Section'
import { CuteButton, SoftButton } from './CuteButton'
import { useAdhwa } from '@/lib/adhwa/store'
import { burstHearts, burstFromElement } from '@/lib/adhwa/burst'
import { placeholderPhoto } from '@/lib/adhwa/image'

const FLOATERS = ['💗', '💖', '✨', '🌸', '🎀', '💕']

export function Hero() {
  const data = useAdhwa((s) => s.data)
  const heroSrc = useAdhwa((s) => s.media['hero'])
  const goTo = (id: string) => (e: React.MouseEvent<HTMLButtonElement>) => {
    burstFromElement(e.currentTarget, { count: 8 })
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
  }

  const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' })

  return (
    <section id="hero" className="relative z-10 mx-auto w-full max-w-5xl scroll-mt-20 px-4 pb-10 pt-4 sm:pt-10">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: 'easeOut' }}
        className="text-center"
      >
        <button onClick={scrollToTop} className="font-script text-xl text-rose-500 transition hover:scale-105" aria-label="Ke atas">
          {data.siteTitle} ✨
        </button>
        <h1 className="font-display mt-2 text-4xl font-extrabold leading-tight text-rose-950 sm:text-6xl">
          {data.hero.title},
        </h1>
        <motion.h1
          className="font-script text-5xl font-bold text-transparent sm:text-7xl"
          style={{
            backgroundImage: 'linear-gradient(90deg,#E75480,#FF7AA2,#B76E79,#E75480)',
            backgroundSize: '200% 100%',
            WebkitBackgroundClip: 'text',
            backgroundClip: 'text',
          }}
          animate={{ backgroundPosition: ['0% 50%', '200% 50%'] }}
          transition={{ duration: 6, repeat: Infinity, ease: 'linear' }}
        >
          {data.herName}! 💗
        </motion.h1>

        <GlassCard className="mx-auto mt-8 max-w-2xl">
          <p className="font-script text-xl leading-relaxed text-rose-800 sm:text-2xl">
            &ldquo;{data.hero.quote}&rdquo;
          </p>
        </GlassCard>

        {/* polaroid photo frame */}
        <div className="relative mx-auto mt-10 w-fit">
          {FLOATERS.map((e, i) => (
            <motion.span
              key={i}
              className="pointer-events-none absolute select-none text-2xl sm:text-3xl"
              style={{
                left: [-30, 'auto', 'auto', -40, 'auto', 'auto'][i] as string | number,
                right: i % 3 === 1 ? -30 : i % 3 === 2 ? -18 : 'auto',
                top: [-18, -14, 40, 'auto', 'auto', 'auto'][i] as string | number,
                bottom: i === 3 ? -16 : i === 4 ? 30 : i === 5 ? -22 : 'auto',
              }}
              animate={{ y: [0, -14, 0], rotate: [0, 10, -10, 0] }}
              transition={{ duration: 3 + (i % 3), repeat: Infinity, delay: i * 0.5 }}
            >
              {e}
            </motion.span>
          ))}

          <motion.div
            className="relative rounded-3xl bg-white p-3 pb-10 shadow-[0_18px_50px_rgba(231,84,128,0.3)]"
            style={{ transform: 'rotate(-2deg)' }}
            whileHover={{ rotate: 0, scale: 1.03 }}
            transition={{ type: 'spring', stiffness: 200 }}
          >
            <span className="absolute -top-3 left-6 h-7 w-20 rotate-[-8deg] rounded-sm bg-pink-300/60 backdrop-blur-sm" />
            <span className="absolute -top-2 right-8 h-7 w-16 rotate-[10deg] rounded-sm bg-rose-300/50 backdrop-blur-sm" />
            { }
            <img
              src={heroSrc || placeholderPhoto(1, 'Foto Kita Berdua')}
              alt={`Foto kenangan ${data.herName}`}
              className="h-64 w-56 rounded-2xl object-cover sm:h-80 sm:w-72"
              onClick={(e) => burstHearts(e.clientX, e.clientY, { count: 12 })}
            />
            <p className="font-script mt-3 text-center text-2xl text-rose-700">aku &amp; kamu 🤍</p>
          </motion.div>
        </div>

        <div className="mt-10 flex flex-wrap justify-center gap-3">
          <CuteButton onClick={goTo('gallery')} size="lg">
            Lihat Kenangan Kita 📸
          </CuteButton>
          <SoftButton onClick={goTo('letters')} size="lg">
            Baca Surat Buat Kamu 💌
          </SoftButton>
        </div>
      </motion.div>
    </section>
  )
}
