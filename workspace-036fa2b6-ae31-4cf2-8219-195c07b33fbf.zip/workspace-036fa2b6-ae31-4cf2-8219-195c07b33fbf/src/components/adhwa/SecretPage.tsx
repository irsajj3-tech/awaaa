'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Section, GlassCard } from './Section'
import { CuteButton, SoftButton } from './CuteButton'
import { Input } from '@/components/ui/input'
import { useAdhwa } from '@/lib/adhwa/store'
import { randomBurst, burstHearts } from '@/lib/adhwa/burst'
import { useToast } from '@/hooks/use-toast'

export function SecretPage() {
  const secretPassword = useAdhwa((s) => s.data.secretPassword)
  const secretLetter = useAdhwa((s) => s.data.secretLetter)
  const herName = useAdhwa((s) => s.data.herName)
  const [unlocked, setUnlocked] = useState(false)
  const [pw, setPw] = useState('')
  const [shake, setShake] = useState(false)
  const [opening, setOpening] = useState(false)
  const { toast } = useToast()

  const tryUnlock = (e: React.MouseEvent<HTMLButtonElement>) => {
    const ok = pw.trim().toLowerCase() === secretPassword.trim().toLowerCase()
    if (ok) {
      burstHearts(e.clientX, e.clientY, { count: 20, power: 220, size: 24 })
      setOpening(true)
      randomBurst(8, { count: 10, emojis: ['💗', '💖', '💘', '✨', '🌸'] })
      setTimeout(() => {
        setOpening(false)
        setUnlocked(true)
      }, 1600)
    } else {
      setShake(true)
      setTimeout(() => setShake(false), 550)
      toast({
        title: 'Password salah 🥺',
        description: 'Clue-nya: nama kamu + kata yang selalu aku ucapin tiap malam... atau tanya pacarmu 😆',
      })
    }
  }

  const paragraphs = secretLetter.split(/\n\n+/)

  return (
    <Section
      id="secret"
      emoji="🌹"
      kicker="hanya untuk mata kamu saja"
      title="Secret Love Page"
      sub="Halaman ini terkunci. Ada satu surat panjang yang paling jujur di dalamnya — password-nya cuma kita berdua yang tahu."
    >
      <div className="mx-auto max-w-2xl">
        <AnimatePresence mode="wait">
          {!unlocked ? (
            <motion.div
              key="locked"
              initial={{ opacity: 0, y: 20 }}
              animate={shake ? { x: [0, -12, 12, -8, 8, 0], opacity: 1 } : { x: 0, opacity: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.45 }}
            >
              <GlassCard className="text-center">
                <motion.span
                  className="inline-block text-6xl"
                  animate={{ rotate: [0, -6, 6, 0], scale: [1, 1.08, 1] }}
                  transition={{ duration: 2.2, repeat: Infinity }}
                >
                  🔐
                </motion.span>
                <p className="mt-4 text-sm text-rose-700/85">
                  Masukin password rahasianya, {herName} 🌹
                </p>
                <div className="mx-auto mt-5 flex max-w-sm flex-col gap-3 sm:flex-row">
                  <Input
                    type="password"
                    value={pw}
                    onChange={(e) => setPw(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && e.currentTarget.form === null) {
                        tryUnlock({ clientX: window.innerWidth / 2, clientY: window.innerHeight / 2 } as unknown as React.MouseEvent<HTMLButtonElement>)
                      }
                    }}
                    placeholder="password rahasia..."
                    className="border-pink-200 bg-white/85 text-center focus-visible:ring-pink-300"
                  />
                  <CuteButton onClick={tryUnlock}>Buka 🗝️</CuteButton>
                </div>
                <p className="mt-4 text-[11px] text-rose-500/70">
                  Lupa password? Tanya pembuat dunia ini 😆 (bisa diganti lewat tombol 🔧)
                </p>
              </GlassCard>
            </motion.div>
          ) : opening ? (
            <motion.div key="opening" className="text-center" exit={{ opacity: 0 }}>
              <motion.div
                className="mx-auto text-8xl"
                animate={{ rotate: [0, -10, 10, -6, 6, 0], scale: [1, 1.2, 1.35], y: [0, -16, 0] }}
                transition={{ duration: 1.5 }}
              >
                💌
              </motion.div>
              <p className="font-script mt-4 animate-pulse text-2xl text-rose-600">membuka surat rahasia...</p>
            </motion.div>
          ) : (
            <motion.div key="letter" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.6 }}>
              <div className="rounded-3xl bg-[#FFFDF6] p-7 shadow-[0_20px_60px_rgba(231,84,128,0.25)] sm:p-10">
                <div className="mb-6 text-center">
                  <span className="text-4xl">🌹</span>
                  <h3 className="font-script mt-2 text-3xl text-rose-700">Untuk {herName}, yang paling istimewa</h3>
                  <div className="mt-3 flex items-center justify-center gap-2 text-pink-300">
                    <span className="h-px w-14 bg-gradient-to-r from-transparent to-pink-300" />
                    <span>💗</span>
                    <span className="h-px w-14 bg-gradient-to-l from-transparent to-pink-300" />
                  </div>
                </div>
                <div className="space-y-4">
                  {paragraphs.map((p, i) => (
                    <p key={i} className="text-[15px] leading-relaxed whitespace-pre-line text-rose-950/90">
                      {p}
                    </p>
                  ))}
                </div>
              </div>
              <div className="mt-5 flex justify-center">
                <SoftButton
                  onClick={() => {
                    setUnlocked(false)
                    setPw('')
                  }}
                >
                  🔒 Kunci Lagi Halamannya
                </SoftButton>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </Section>
  )
}
