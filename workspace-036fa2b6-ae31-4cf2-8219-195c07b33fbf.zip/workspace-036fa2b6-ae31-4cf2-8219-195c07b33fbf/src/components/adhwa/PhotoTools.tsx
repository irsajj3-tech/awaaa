'use client'

// Shared photo-upload flows with preview-before-save.
// Used by the Gallery and the Admin panel.

import { useRef, useState } from 'react'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { CuteButton } from './CuteButton'
import { fileToDataUrl } from '@/lib/adhwa/image'
import { useToast } from '@/hooks/use-toast'

export interface PendingPhoto {
  src: string
  caption: string
}

interface PhotoPickFlowProps {
  label: string
  multiple?: boolean
  defaultCaption?: string
  onSave: (photos: PendingPhoto[]) => void
  className?: string
  children?: React.ReactNode
}

export function PhotoPickFlow({ label, multiple = false, defaultCaption = 'Kenangan manis 🌷', onSave, className }: PhotoPickFlowProps) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [pending, setPending] = useState<PendingPhoto[] | null>(null)
  const [busy, setBusy] = useState(false)
  const { toast } = useToast()

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return
    setBusy(true)
    try {
      const list: PendingPhoto[] = []
      for (const f of Array.from(files)) {
        if (!f.type.startsWith('image/')) continue
        const src = await fileToDataUrl(f)
        list.push({ src, caption: defaultCaption })
      }
      if (list.length === 0) {
        toast({ title: 'Hmm... 🤔', description: 'File yang dipilih bukan gambar ya.' })
        return
      }
      setPending(multiple ? list : list.slice(0, 1))
    } catch {
      toast({ title: 'Gagal membaca foto 😢', description: 'Coba foto lain ya.' })
    } finally {
      setBusy(false)
      if (inputRef.current) inputRef.current.value = ''
    }
  }

  const save = () => {
    if (!pending || pending.length === 0) return
    onSave(pending)
    setPending(null)
    toast({ title: 'Tersimpan! 💗', description: 'Foto baru sudah masuk ke galeri cinta kita.' })
  }

  return (
    <>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        multiple={multiple}
        className="hidden"
        onChange={(e) => void handleFiles(e.target.files)}
      />
      <CuteButton className={className} onClick={() => inputRef.current?.click()} disabled={busy}>
        {busy ? 'Menyiapkan foto... ⏳' : label}
      </CuteButton>

      <Dialog open={!!pending} onOpenChange={(v) => !v && setPending(null)}>
        <DialogContent className="max-h-[85vh] overflow-y-auto pink-scroll rounded-3xl border-pink-200 bg-[#FFF7F9] sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-display text-rose-800">Preview Foto 📸</DialogTitle>
            <DialogDescription className="text-rose-600/80">
              Cek dulu, baru simpan. Caption bisa kamu ubah di sini juga.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4">
            {pending?.map((p, i) => (
              <div key={i} className="rounded-2xl border border-pink-100 bg-white p-3">
                { }
                <img src={p.src} alt={`Preview ${i + 1}`} className="max-h-64 w-full rounded-xl object-cover" />
                <Input
                  value={p.caption}
                  onChange={(e) => {
                    const val = e.target.value
                    setPending((prev) => prev?.map((x, j) => (j === i ? { ...x, caption: val } : x)) ?? null)
                  }}
                  placeholder="Caption foto..."
                  className="mt-2 border-pink-200 focus-visible:ring-pink-300"
                />
              </div>
            ))}
            <div className="flex justify-end gap-2">
              <CuteButton variant="outline" className="border-pink-300 bg-white/70 text-rose-600 hover:bg-pink-50" onClick={() => setPending(null)}>
                Batal
              </CuteButton>
              <CuteButton onClick={save}>Simpan ke Galeri 💗</CuteButton>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}

interface SinglePhotoPickProps {
  label: string
  onSave: (src: string) => void
}

export function SinglePhotoPick({ label, onSave }: SinglePhotoPickProps) {
  return (
    <PhotoPickFlow
      label={label}
      defaultCaption=""
      onSave={(photos) => onSave(photos[0].src)}
    />
  )
}
