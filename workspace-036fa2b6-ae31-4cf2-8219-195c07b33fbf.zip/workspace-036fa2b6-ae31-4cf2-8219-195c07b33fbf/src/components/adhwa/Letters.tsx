'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Section } from './Section'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { useAdhwa } from '@/lib/adhwa/store'
import { burstFromElement } from '@/lib/adhwa/burst'

export function Letters() {
  const letters = useAdhwa((s) => s.data.letters)
  const [openIdx, setOpenIdx] = useState<number | null>(null)

  return (
    <Section
      id="letters"
      emoji="🥺"
      kicker="klik amplopnya pelan-pelan ya"
      title="Open When Letters"
      sub="Kumpulan surat untuk semua suasana hatimu. Buka sesuai kondisi kamu hari ini — masing-masing isinya berbeda dan buat kamu saja."
    >
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {letters.map((l, i) => (
          <motion.button
            key={l.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: (i % 3) * 0.08, duration: 0.45 }}
            whileHover={{ y: -4, rotate: i % 2 === 0 ? -1 : 1 }}
            whileTap={{ scale: 0.95 }}
            className="group relative mx-auto w-full max-w-sm overflow-hidden rounded-2xl border border-pink-200 bg-gradient-to-br from-[#FFE3ED] to-[#FFCFE0] p-5 text-left shadow-[0_10px_30px_rgba(231,84,128,0.18)]"
            onClick={(e) => {
              burstFromElement(e.currentTarget, { count: 10 })
              setOpenIdx(i)
            }}
            aria-label={`Buka surat: ${l.title}`}
          >
            {/* flap */}
            <span className="absolute right-4 top-4 h-8 w-8 rotate-45 rounded-sm bg-pink-200/80 transition-transform group-hover:scale-110" />
            <span className="absolute right-[1.15rem] top-[1.15rem] text-sm transition-transform group-hover:scale-125">💗</span>
            <span className="text-4xl transition-transform group-hover:-rotate-6 group-hover:scale-110">💌</span>
            <p className="font-script mt-3 text-2xl leading-snug text-rose-800">{l.title}</p>
            <p className="mt-1 text-xs text-rose-500/80">— untuk kamu, dari aku —</p>
          </motion.button>
        ))}
      </div>

      <Dialog open={openIdx !== null} onOpenChange={(v) => !v && setOpenIdx(null)}>
        <DialogContent className="max-h-[85vh] overflow-y-auto pink-scroll rounded-3xl border-pink-200 bg-[#FFFDF6] sm:max-w-lg">
          {openIdx !== null && letters[openIdx] && (
            <motion.div
              initial={{ scaleY: 0.7, opacity: 0.4 }}
              animate={{ scaleY: 1, opacity: 1 }}
              transition={{ duration: 0.4, ease: 'easeOut' }}
              style={{ transformOrigin: 'top' }}
            >
              <DialogHeader>
                <DialogTitle className="font-script text-3xl text-rose-700">{letters[openIdx].title}</DialogTitle>
              </DialogHeader>
              <div className="mt-4 space-y-3 whitespace-pre-line font-sans text-[15px] leading-relaxed text-rose-950/90">
                {letters[openIdx].body}
              </div>
              <p className="font-script mt-6 text-right text-xl text-rose-600">— dari yang sayang kamu banget 🤍</p>
            </motion.div>
          )}
        </DialogContent>
      </Dialog>

      {/* cute floating hint */}
      <AnimatePresence>
        <motion.p
          className="mt-6 text-center text-xs text-rose-500/70"
          animate={{ opacity: [0.6, 1, 0.6] }}
          transition={{ duration: 2.4, repeat: Infinity }}
        >
          💡 nanti aku tulisin surat-surat baru lewat tombol 🔧 juga
        </motion.p>
      </AnimatePresence>
    </Section>
  )
}
