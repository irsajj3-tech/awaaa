'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Section } from './Section'
import { CuteButton, SoftButton } from './CuteButton'
import { PhotoPickFlow } from './PhotoTools'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { useAdhwa, getMediaKeyForPhoto } from '@/lib/adhwa/store'
import { placeholderPhoto } from '@/lib/adhwa/image'
import { burstHearts } from '@/lib/adhwa/burst'
import { useToast } from '@/hooks/use-toast'

const CAPTION_DEFAULT = 'Kenangan manis 🌷'

export function Gallery() {
  const data = useAdhwa((s) => s.data)
  const media = useAdhwa((s) => s.media)
  const setData = useAdhwa((s) => s.setData)
  const setMedia = useAdhwa((s) => s.setMedia)
  const mediaReady = useAdhwa((s) => s.mediaReady)
  const { toast } = useToast()

  const [lightbox, setLightbox] = useState<number | null>(null)
  const [editIdx, setEditIdx] = useState<number | null>(null)
  const [editCaption, setEditCaption] = useState('')
  const [replaceIdx, setReplaceIdx] = useState<number | null>(null)
  const [pendingReplace, setPendingReplace] = useState<string | null>(null)
  const [deleteIdx, setDeleteIdx] = useState<number | null>(null)
  const [busy, setBusy] = useState(false)

  const items = data.gallery
  const srcOf = (id: string, i: number) => media[getMediaKeyForPhoto(id)] || placeholderPhoto(i)

  const addPhotosWithMedia = async (photos: { src: string; caption: string }[]) => {
    const newItems = photos.map((p) => ({
      id: `ph-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      caption: p.caption || CAPTION_DEFAULT,
    }))
    setData((d) => ({ ...d, gallery: [...d.gallery, ...newItems] }))
    for (let i = 0; i < newItems.length; i++) {
      await setMedia(getMediaKeyForPhoto(newItems[i].id), photos[i].src)
    }
  }

  const replacePhoto = async () => {
    if (replaceIdx === null || !pendingReplace) return
    const item = items[replaceIdx]
    if (!item) return
    setBusy(true)
    await setMedia(getMediaKeyForPhoto(item.id), pendingReplace)
    setBusy(false)
    setPendingReplace(null)
    setReplaceIdx(null)
    toast({ title: 'Foto diganti! 💫', description: 'Semester baru kenangan yang cantik.' })
  }

  const confirmDelete = async () => {
    if (deleteIdx === null) return
    const item = items[deleteIdx]
    if (!item) return
    await setMedia(getMediaKeyForPhoto(item.id), null)
    setData((d) => ({ ...d, gallery: d.gallery.filter((g) => g.id !== item.id) }))
    setDeleteIdx(null)
    toast({ title: 'Foto dihapus', description: 'Kalau nyesel, upload lagi ya 😆' })
  }

  const saveCaption = () => {
    if (editIdx === null) return
    const item = items[editIdx]
    if (!item) return
    setData((d) => ({
      ...d,
      gallery: d.gallery.map((g) => (g.id === item.id ? { ...g, caption: editCaption } : g)),
    }))
    setEditIdx(null)
    toast({ title: 'Caption tersimpan ✨' })
  }

  const navLightbox = (dir: 1 | -1) => {
    if (lightbox === null) return
    setLightbox((lightbox + dir + items.length) % items.length)
  }

  return (
    <Section
      id="gallery"
      emoji="📸"
      kicker="setiap foto adalah harta"
      title="Our Lovely Gallery"
      sub="Galeri kenangan kita. Tap foto buat lihat besar, tambah foto baru, edit caption, ganti, atau hapus — semuanya bisa kamu atur sendiri, sayang."
    >
      <div className="mb-6 flex justify-center">
        <PhotoPickFlow label="➕ Tambah Foto" multiple onSave={(photos) => void addPhotosWithMedia(photos)} />
      </div>

      <div className="columns-2 gap-4 md:columns-3 [&>*]:mb-4">
        <AnimatePresence initial={false}>
          {items.map((item, i) => (
            <motion.figure
              key={item.id}
              layout
              initial={{ opacity: 0, scale: 0.85 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ duration: 0.35 }}
              className="glass break-inside-avoid rounded-2xl p-2.5"
            >
              <button
                className="group relative block w-full overflow-hidden rounded-xl"
                onClick={(e) => {
                  setLightbox(i)
                  burstHearts(e.clientX, e.clientY, { count: 5, power: 60, size: 14 })
                }}
                aria-label={`Lihat foto: ${item.caption}`}
              >
                { }
                <img
                  src={srcOf(item.id, i)}
                  alt={item.caption}
                  loading="lazy"
                  className="w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <span className="absolute inset-0 bg-gradient-to-t from-rose-500/25 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
              </button>
              <figcaption className="mt-2 flex items-center justify-between gap-1 px-1">
                <span className="font-script truncate text-lg text-rose-800">{item.caption}</span>
                <span className="flex shrink-0 gap-0.5">
                  <button
                    className="rounded-full px-1.5 py-0.5 text-sm transition hover:bg-pink-100"
                    aria-label="Ganti foto"
                    onClick={() => {
                      setReplaceIdx(i)
                      setPendingReplace(null)
                    }}
                  >
                    🔄
                  </button>
                  <button
                    className="rounded-full px-1.5 py-0.5 text-sm transition hover:bg-pink-100"
                    aria-label="Edit caption"
                    onClick={() => {
                      setEditIdx(i)
                      setEditCaption(item.caption)
                    }}
                  >
                    ✏️
                  </button>
                  <button
                    className="rounded-full px-1.5 py-0.5 text-sm transition hover:bg-pink-100"
                    aria-label="Hapus foto"
                    onClick={() => setDeleteIdx(i)}
                  >
                    🗑️
                  </button>
                </span>
              </figcaption>
            </motion.figure>
          ))}
        </AnimatePresence>
      </div>

      {items.length === 0 && (
        <p className="text-center text-sm text-rose-600/70">Galerinya masih kosong... upload foto pertama kalian dong 🥺📸</p>
      )}

      {/* Lightbox */}
      <Dialog open={lightbox !== null} onOpenChange={(v) => !v && setLightbox(null)}>
        <DialogContent className="rounded-3xl border-pink-200 bg-[#FFF7F9] sm:max-w-xl">
          {lightbox !== null && items[lightbox] && (
            <>
              <DialogHeader>
                <DialogTitle className="font-script text-2xl text-rose-700">{items[lightbox].caption}</DialogTitle>
              </DialogHeader>
              { }
              <img
                src={srcOf(items[lightbox].id, lightbox)}
                alt={items[lightbox].caption}
                className="max-h-[60vh] w-full rounded-2xl object-contain"
              />
              <div className="flex justify-center gap-3">
                <SoftButton onClick={() => navLightbox(-1)}>‹ Sebelumnya</SoftButton>
                <SoftButton onClick={() => navLightbox(1)}>Berikutnya ›</SoftButton>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit caption dialog */}
      <Dialog open={editIdx !== null} onOpenChange={(v) => !v && setEditIdx(null)}>
        <DialogContent className="rounded-3xl border-pink-200 bg-[#FFF7F9] sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="font-display text-rose-800">Edit Caption ✏️</DialogTitle>
          </DialogHeader>
          <Input
            value={editCaption}
            onChange={(e) => setEditCaption(e.target.value)}
            className="border-pink-200 focus-visible:ring-pink-300"
            placeholder="Tulis caption manis..."
          />
          <div className="flex justify-end">
            <CuteButton onClick={saveCaption}>Simpan 💗</CuteButton>
          </div>
        </DialogContent>
      </Dialog>

      {/* Replace photo dialog */}
      <Dialog open={replaceIdx !== null} onOpenChange={(v) => !v && setReplaceIdx(null)}>
        <DialogContent className="rounded-3xl border-pink-200 bg-[#FFF7F9] sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="font-display text-rose-800">Ganti Foto 🔄</DialogTitle>
          </DialogHeader>
          {pendingReplace ? (
            <div className="rounded-2xl border border-pink-100 bg-white p-3">
              { }
              <img src={pendingReplace} alt="Preview foto baru" className="max-h-56 w-full rounded-xl object-cover" />
            </div>
          ) : (
            <p className="text-sm text-rose-700/80">Pilih foto baru dari galeri HP/komputer kamu. Preview dulu sebelum disimpan ya.</p>
          )}
          <label className="block">
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={async (e) => {
                const f = e.target.files?.[0]
                if (!f) return
                setBusy(true)
                const { fileToDataUrl } = await import('@/lib/adhwa/image')
                setPendingReplace(await fileToDataUrl(f))
                setBusy(false)
                e.target.value = ''
              }}
            />
            <span className="inline-flex h-10 cursor-pointer items-center justify-center rounded-full border border-pink-300 bg-white/80 px-5 text-sm font-bold text-rose-600 transition hover:bg-pink-50 active:scale-95">
              {busy ? 'Menyiapkan... ⏳' : '📁 Pilih Foto'}
            </span>
          </label>
          <div className="flex justify-end gap-2">
            <SoftButton onClick={() => setReplaceIdx(null)}>Batal</SoftButton>
            <CuteButton disabled={!pendingReplace} onClick={() => void replacePhoto()}>
              Simpan Foto Baru 💗
            </CuteButton>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <AlertDialog open={deleteIdx !== null} onOpenChange={(v) => !v && setDeleteIdx(null)}>
        <AlertDialogContent className="rounded-3xl border-pink-200 bg-[#FFF7F9]">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-rose-800">Hapus foto ini? 🗑️</AlertDialogTitle>
            <AlertDialogDescription className="text-rose-700/80">
              Foto &ldquo;{deleteIdx !== null && items[deleteIdx] ? items[deleteIdx].caption : ''}&rdquo; akan dihapus dari galeri. Ini nggak bisa dibatalkan loh!
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-full border-pink-200 text-rose-600">Batal</AlertDialogCancel>
            <AlertDialogAction className="rounded-full bg-rose-500 text-white hover:bg-rose-600" onClick={() => void confirmDelete()}>
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Section>
  )
}
