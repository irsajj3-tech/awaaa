'use client'

import { motion } from 'framer-motion'
import { Section, GlassCard } from './Section'
import { useAdhwa } from '@/lib/adhwa/store'
import type { DreamItem } from '@/lib/adhwa/types'

function ScrapBook({
  title,
  items,
  tilt,
  tape,
}: {
  title: string
  items: DreamItem[]
  tilt: string
  tape: string
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30, rotate: 0 }}
      whileInView={{ opacity: 1, y: 0, rotate: tilt === 'left' ? -1.2 : tilt === 'right' ? 1.2 : 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className={`glass relative rounded-3xl p-5 pt-8 ${tilt === 'left' ? 'md:-rotate-1' : tilt === 'right' ? 'md:rotate-1' : ''}`}
    >
      <span className={`absolute -top-3 left-1/2 h-7 w-24 -translate-x-1/2 rotate-[-4deg] rounded-sm ${tape} backdrop-blur-sm`} />
      <h3 className="font-script mb-4 text-center text-2xl text-rose-700">{title}</h3>
      <ul className="space-y-3">
        {items.map((it, i) => (
          <motion.li
            key={it.id}
            initial={{ opacity: 0, x: -14 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.05 }}
            className="rounded-2xl border border-pink-100 bg-white/70 px-4 py-3 transition hover:border-pink-300 hover:bg-white"
          >
            <p className="flex items-center gap-2 text-sm font-bold text-rose-800">
              <span className="text-lg">{it.emoji}</span>
              {it.title}
            </p>
            {it.note && <p className="mt-1 pl-7 text-xs leading-relaxed text-rose-600/85">{it.note}</p>}
          </motion.li>
        ))}
      </ul>
    </motion.div>
  )
}

export function Future() {
  const future = useAdhwa((s) => s.data.future)
  const herName = useAdhwa((s) => s.data.herName)

  return (
    <Section
      id="future"
      emoji="🌷"
      kicker="peta menuju selamanya"
      title={future.title}
      sub={`Scrapbook impian kita berdua. Semua ini kosong kalau kamu nggak di dalamnya, ${herName} — makanya jangan ke mana-mana ya.`}
    >
      <div className="grid gap-6 md:grid-cols-3">
        <ScrapBook title="🗺️ Tempat yang Mau Kita Datangi" items={future.places} tilt="left" tape="bg-pink-300/70" />
        <ScrapBook title="🎯 Hal yang Mau Kita Lakukan" items={future.dreams} tilt="mid" tape="bg-rose-300/70" />
        <ScrapBook title="🤝 Janji-Janji Manis" items={future.promises} tilt="right" tape="bg-fuchsia-300/70" />
      </div>
      <GlassCard className="mt-8 text-center">
        <p className="font-script text-xl text-rose-700 sm:text-2xl">
          &ldquo;Impian kecil dan besar kita, semua akan kukejar — pelan-pelan, bareng kamu.&rdquo; 🌷
        </p>
      </GlassCard>
    </Section>
  )
}
