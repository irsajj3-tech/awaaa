'use client'

import { useEffect, useState } from 'react'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { useAdhwa, useUi, getMediaKeyForPhoto } from '@/lib/adhwa/store'
import { PhotoPickFlow } from './PhotoTools'
import { audioToDataUrl } from '@/lib/adhwa/image'
import { burstHearts } from '@/lib/adhwa/burst'
import { useToast } from '@/hooks/use-toast'
import { DEFAULT_DATA } from '@/lib/adhwa/defaults'
import type { AdhwaData, DreamItem } from '@/lib/adhwa/types'

/* ---------- small helpers ---------- */

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-bold text-rose-700">{label}</Label>
      {children}
    </div>
  )
}

function LinesEditor({ value, onSave, rows = 10, placeholder }: { value: string[]; onSave: (lines: string[]) => void; rows?: number; placeholder?: string }) {
  // draft === null means "follow the external value" (no effect needed)
  const [draft, setDraft] = useState<string | null>(null)
  const shown = draft ?? value.join('\n')
  const dirty = draft !== null
  return (
    <div className="space-y-2">
      <Textarea
        rows={rows}
        value={shown}
        placeholder={placeholder}
        onChange={(e) => setDraft(e.target.value)}
        className="border-pink-200 bg-white/90 font-mono text-xs focus-visible:ring-pink-300"
      />
      <div className="flex items-center gap-3">
        <Button
          size="sm"
          disabled={!dirty}
          onClick={() => {
            onSave(shown.split('\n').map((l) => l.trim()).filter(Boolean))
            setDraft(null)
            burstHearts(window.innerWidth / 2, window.innerHeight / 2, { count: 8 })
          }}
          className="rounded-full bg-rose-500 text-white hover:bg-rose-600"
        >
          💾 Simpan Perubahan
        </Button>
        {dirty && <span className="text-xs text-amber-600">ada perubahan belum disimpan</span>}
      </div>
    </div>
  )
}

function LongTextEditor({ value, onSave, rows = 8, label }: { value: string; onSave: (v: string) => void; rows?: number; label?: string }) {
  const [draft, setDraft] = useState<string | null>(null)
  const shown = draft ?? value
  const dirty = draft !== null
  return (
    <div className="space-y-2">
      <Textarea
        rows={rows}
        value={shown}
        aria-label={label}
        onChange={(e) => setDraft(e.target.value)}
        className="border-pink-200 bg-white/90 text-sm leading-relaxed focus-visible:ring-pink-300"
      />
      <div className="flex items-center gap-3">
        <Button
          size="sm"
          disabled={!dirty}
          onClick={() => {
            onSave(shown)
            setDraft(null)
            burstHearts(window.innerWidth / 2, window.innerHeight / 2, { count: 8 })
          }}
          className="rounded-full bg-rose-500 text-white hover:bg-rose-600"
        >
          💾 Simpan Perubahan
        </Button>
        {dirty && <span className="text-xs text-amber-600">ada perubahan belum disimpan</span>}
      </div>
    </div>
  )
}

/* ---------- item editors ---------- */

function DreamListEditor({ items, onChange, emptyLabel }: { items: DreamItem[]; onChange: (items: DreamItem[]) => void; emptyLabel: string }) {
  return (
    <div className="space-y-3">
      {items.map((it, i) => (
        <div key={it.id} className="rounded-2xl border border-pink-100 bg-white/80 p-3">
          <div className="flex gap-2">
            <Input
              value={it.emoji}
              onChange={(e) => onChange(items.map((x, j) => (j === i ? { ...x, emoji: e.target.value } : x)))}
              className="w-16 text-center"
              aria-label="Emoji"
            />
            <Input
              value={it.title}
              onChange={(e) => onChange(items.map((x, j) => (j === i ? { ...x, title: e.target.value } : x)))}
              className="flex-1"
              placeholder="Judul"
            />
            <Button
              size="icon"
              variant="ghost"
              className="shrink-0 text-rose-400 hover:bg-pink-100 hover:text-rose-600"
              onClick={() => onChange(items.filter((_, j) => j !== i))}
              aria-label="Hapus item"
            >
              🗑️
            </Button>
          </div>
          <Input
            value={it.note}
            onChange={(e) => onChange(items.map((x, j) => (j === i ? { ...x, note: e.target.value } : x)))}
            className="mt-2"
            placeholder={emptyLabel}
          />
        </div>
      ))}
      <Button
        size="sm"
        variant="outline"
        className="rounded-full border-pink-300 text-rose-600 hover:bg-pink-50"
        onClick={() => onChange([...items, { id: `di-${Date.now()}`, emoji: '💗', title: 'Impian baru', note: emptyLabel }])}
      >
        ➕ Tambah Item
      </Button>
    </div>
  )
}

/* ---------- main panel ---------- */

export function AdminPanel() {
  const adminOpen = useUi((s) => s.adminOpen)
  const setAdminOpen = useUi((s) => s.setAdminOpen)
  const data = useAdhwa((s) => s.data)
  const media = useAdhwa((s) => s.media)
  const update = useAdhwa((s) => s.update)
  const setData = useAdhwa((s) => s.setData)
  const setMedia = useAdhwa((s) => s.setMedia)
  const importAll = useAdhwa((s) => s.importAll)
  const resetAll = useAdhwa((s) => s.resetAll)
  const { toast } = useToast()
  const [confirmReset, setConfirmReset] = useState(false)
  const [importing, setImporting] = useState(false)

  const storageSize = (() => {
    try {
      const total = JSON.stringify(data).length + Object.entries(media).reduce((a, [k, v]) => a + k.length + v.length, 0)
      return (total / 1024 / 1024).toFixed(2)
    } catch {
      return '?'
    }
  })()

  const exportData = () => {
    const payload = { app: 'a-little-world-for-adhwa', version: 1, exportedAt: new Date().toISOString(), data, media }
    const blob = new Blob([JSON.stringify(payload)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'a-little-world-for-adhwa-backup.json'
    a.click()
    URL.revokeObjectURL(url)
    toast({ title: 'Backup diunduh! 💾', description: 'Simpan file-nya, bisa dipindah ke HP atau laptop lain.' })
  }

  const importData = async (f: File | undefined) => {
    if (!f) return
    setImporting(true)
    try {
      const text = await f.text()
      const obj = JSON.parse(text)
      if (!obj?.data?.siteTitle) throw new Error('invalid')
      await importAll(obj.data as AdhwaData, (obj.media ?? {}) as Record<string, string>)
      toast({ title: 'Data berhasil diimpor! 💗', description: 'Semua kenangan sudah pindah ke browser ini.' })
    } catch {
      toast({ title: 'Gagal impor 😢', description: 'Pastikan file-nya adalah backup dari dunia kecil ini ya.' })
    } finally {
      setImporting(false)
    }
  }

  const addPhotosWithMedia = async (photos: { src: string; caption: string }[]) => {
    const newItems = photos.map((p) => ({
      id: `ph-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      caption: p.caption || 'Kenangan manis 🌷',
    }))
    setData((d) => ({ ...d, gallery: [...d.gallery, ...newItems] }))
    for (let i = 0; i < newItems.length; i++) {
      await setMedia(getMediaKeyForPhoto(newItems[i].id), photos[i].src)
    }
  }

  return (
    <Dialog open={adminOpen} onOpenChange={setAdminOpen}>
      <DialogContent className="flex max-h-[92vh] flex-col overflow-hidden rounded-3xl border-pink-200 bg-[#FFF7F9] p-0 sm:max-w-3xl">
        <DialogHeader className="border-b border-pink-100 px-6 pb-4 pt-6">
          <DialogTitle className="font-display text-2xl text-rose-800">🔧 Ruang Admin Cinta</DialogTitle>
          <DialogDescription className="text-rose-600/80">
            Semua tulisan, foto, dan pengaturan dunia kecil ini bisa kamu ubah di sini. Perubahan tersimpan otomatis di browser.
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="umum" className="flex min-h-0 flex-1 flex-col">
          <div className="overflow-x-auto px-6 pt-3 pink-scroll">
            <TabsList className="w-max bg-pink-100/80">
              {[
                ['umum', '💞 Umum'],
                ['galeri', '📸 Galeri'],
                ['alasan', '💗 Alasan'],
                ['surat', '💌 Surat'],
                ['kuis', '🎀 Kuis'],
                ['hadiah', '🎁 Hadiah'],
                ['mood', '💓 Mood & Kangen'],
                ['impian', '🌷 Impian'],
                ['rahasia', '🌹 Rahasia'],
                ['penutup', '📜 Penutup'],
                ['musik', '🎵 Musik'],
                ['data', '💾 Data'],
              ].map(([v, l]) => (
                <TabsTrigger key={v} value={v} className="rounded-full data-[state=active]:bg-white data-[state=active]:text-rose-700">
                  {l}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          <div className="pink-scroll min-h-0 flex-1 overflow-y-auto px-6 py-5">
            {/* ---- Umum ---- */}
            <TabsContent value="umum" className="space-y-4">
              <Field label="Judul website">
                <Input value={data.siteTitle} onChange={(e) => update({ siteTitle: e.target.value })} className="border-pink-200" />
              </Field>
              <Field label="Nama panggilan cewekmu (nama dia)">
                <Input value={data.herName} onChange={(e) => update({ herName: e.target.value })} className="border-pink-200" />
              </Field>
              <Field label="Tanggal jadian (untuk love counter)">
                <Input type="datetime-local" value={data.anniversary} onChange={(e) => update({ anniversary: e.target.value })} className="border-pink-200" />
              </Field>
              <Field label="Password halaman rahasia">
                <Input value={data.secretPassword} onChange={(e) => update({ secretPassword: e.target.value })} className="border-pink-200" />
              </Field>
              <div className="rounded-2xl border border-pink-100 bg-white/70 p-4 space-y-3">
                <p className="text-xs font-bold uppercase tracking-wider text-rose-400">Halaman selamat datang</p>
                <Field label="Judul">
                  <Input value={data.welcome.title} onChange={(e) => update({ welcome: { ...data.welcome, title: e.target.value } })} className="border-pink-200" />
                </Field>
                <Field label="Subjudul">
                  <Input value={data.welcome.sub} onChange={(e) => update({ welcome: { ...data.welcome, sub: e.target.value } })} className="border-pink-200" />
                </Field>
                <Field label="Teks tombol">
                  <Input value={data.welcome.btn} onChange={(e) => update({ welcome: { ...data.welcome, btn: e.target.value } })} className="border-pink-200" />
                </Field>
              </div>
              <div className="rounded-2xl border border-pink-100 bg-white/70 p-4 space-y-3">
                <p className="text-xs font-bold uppercase tracking-wider text-rose-400">Hero section</p>
                <Field label="Judul besar">
                  <Input value={data.hero.title} onChange={(e) => update({ hero: { ...data.hero, title: e.target.value } })} className="border-pink-200" />
                </Field>
                <Field label="Kalimat romantis">
                  <Textarea rows={3} value={data.hero.quote} onChange={(e) => update({ hero: { ...data.hero, quote: e.target.value } })} className="border-pink-200" />
                </Field>
                <Field label="Judul love counter">
                  <Input value={data.counterTitle} onChange={(e) => update({ counterTitle: e.target.value })} className="border-pink-200" />
                </Field>
              </div>
            </TabsContent>

            {/* ---- Galeri ---- */}
            <TabsContent value="galeri" className="space-y-4">
              <PhotoPickFlow label="➕ Tambah Foto (bisa banyak)" multiple onSave={(photos) => void addPhotosWithMedia(photos)} />
              <div className="space-y-3">
                {data.gallery.map((g, i) => (
                  <div key={g.id} className="flex items-center gap-3 rounded-2xl border border-pink-100 bg-white/80 p-3">
                    { }
                    <img
                      src={media[getMediaKeyForPhoto(g.id)] || ''}
                      alt={g.caption}
                      className="h-16 w-16 shrink-0 rounded-xl bg-pink-100 object-cover"
                      onError={(e) => ((e.currentTarget.style.visibility = 'hidden'), undefined)}
                    />
                    <Input
                      value={g.caption}
                      onChange={(e) =>
                        setData((d) => ({ ...d, gallery: d.gallery.map((x) => (x.id === g.id ? { ...x, caption: e.target.value } : x)) }))
                      }
                      className="flex-1 border-pink-200"
                      placeholder="Caption foto"
                    />
                    <Button
                      size="icon"
                      variant="ghost"
                      className="shrink-0 text-rose-400 hover:bg-pink-100 hover:text-rose-600"
                      aria-label="Hapus foto"
                      onClick={() => {
                        void setMedia(getMediaKeyForPhoto(g.id), null)
                        setData((d) => ({ ...d, gallery: d.gallery.filter((x) => x.id !== g.id) }))
                      }}
                    >
                      🗑️
                    </Button>
                  </div>
                ))}
                {data.gallery.length === 0 && <p className="text-sm text-rose-500/80">Galeri masih kosong — tambah foto pertama kalian 📸</p>}
              </div>
              <p className="text-xs text-rose-500/70">
                💡 Foto bisa juga diganti/diedit langsung di galeri utama (tombol 🔄 ✏️ 🗑️ di tiap foto).
              </p>
            </TabsContent>

            {/* ---- Alasan ---- */}
            <TabsContent value="alasan" className="space-y-3">
              <p className="text-sm text-rose-700/85">
                Satu alasan = satu baris. Sekarang berisi <b>{data.reasons.length}</b> alasan (idealnya 100).
              </p>
              <LinesEditor
                value={data.reasons}
                onSave={(lines) => update({ reasons: lines })}
                rows={14}
                placeholder="Karena senyummu selalu berhasil memperbaiki hariku.&#10;Karena kamu adalah rumah ternyaman buat aku."
              />
              <Button
                size="sm"
                variant="outline"
                className="rounded-full border-pink-300 text-rose-600 hover:bg-pink-50"
                onClick={() => update({ reasons: DEFAULT_DATA.reasons })}
              >
                ↩️ Kembalikan ke 100 alasan bawaan
              </Button>
            </TabsContent>

            {/* ---- Surat ---- */}
            <TabsContent value="surat" className="space-y-4">
              {data.letters.map((l, i) => (
                <div key={l.id} className="rounded-2xl border border-pink-100 bg-white/80 p-4">
                  <Field label={`Surat ${i + 1} — judul`}>
                    <Input
                      value={l.title}
                      onChange={(e) => setData((d) => ({ ...d, letters: d.letters.map((x) => (x.id === l.id ? { ...x, title: e.target.value } : x)) }))}
                      className="border-pink-200"
                    />
                  </Field>
                  <div className="mt-2">
                    <Field label="Isi surat">
                      <Textarea
                        rows={6}
                        value={l.body}
                        onChange={(e) => setData((d) => ({ ...d, letters: d.letters.map((x) => (x.id === l.id ? { ...x, body: e.target.value } : x)) }))}
                        className="border-pink-200"
                      />
                    </Field>
                  </div>
                </div>
              ))}
            </TabsContent>

            {/* ---- Kuis ---- */}
            <TabsContent value="kuis" className="space-y-4">
              <Field label="Judul kuis">
                <Input value={data.quiz.title} onChange={(e) => setData((d) => ({ ...d, quiz: { ...d.quiz, title: e.target.value } }))} className="border-pink-200" />
              </Field>
              {data.quiz.questions.map((q, qi) => (
                <div key={q.id} className="rounded-2xl border border-pink-100 bg-white/80 p-4">
                  <div className="flex gap-2">
                    <Input
                      value={q.q}
                      onChange={(e) =>
                        setData((d) => ({ ...d, quiz: { ...d.quiz, questions: d.quiz.questions.map((x) => (x.id === q.id ? { ...x, q: e.target.value } : x)) } }))
                      }
                      className="flex-1 border-pink-200"
                      placeholder="Pertanyaan"
                    />
                    <Button
                      size="icon"
                      variant="ghost"
                      className="shrink-0 text-rose-400 hover:bg-pink-100"
                      aria-label="Hapus pertanyaan"
                      onClick={() => setData((d) => ({ ...d, quiz: { ...d.quiz, questions: d.quiz.questions.filter((x) => x.id !== q.id) } }))}
                    >
                      🗑️
                    </Button>
                  </div>
                  <div className="mt-2 grid gap-2 sm:grid-cols-2">
                    {q.options.map((opt, oi) => (
                      <div key={oi} className="flex items-center gap-1.5">
                        <button
                          onClick={() =>
                            setData((d) => ({ ...d, quiz: { ...d.quiz, questions: d.quiz.questions.map((x) => (x.id === q.id ? { ...x, correct: oi } : x)) } }))
                          }
                          className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-bold transition ${
                            q.correct === oi ? 'bg-pink-300 text-white' : 'bg-pink-100 text-rose-500 hover:bg-pink-200'
                          }`}
                          aria-label={`Tandai opsi ${oi + 1} sebagai jawaban benar`}
                          title="Klik = jawaban benar"
                        >
                          {['A', 'B', 'C', 'D'][oi]}
                        </button>
                        <Input
                          value={opt}
                          onChange={(e) =>
                            setData((d) => ({
                              ...d,
                              quiz: { ...d.quiz, questions: d.quiz.questions.map((x) => (x.id === q.id ? { ...x, options: x.options.map((o, j) => (j === oi ? e.target.value : o)) } : x)) },
                            }))
                          }
                          className="border-pink-200"
                          placeholder={`Opsi ${oi + 1}`}
                        />
                      </div>
                    ))}
                  </div>
                  <p className="mt-2 text-[11px] text-rose-500/70">Jawaban benar: {['A', 'B', 'C', 'D'][q.correct] ?? '-'}</p>
                </div>
              ))}
              <Button
                size="sm"
                variant="outline"
                className="rounded-full border-pink-300 text-rose-600 hover:bg-pink-50"
                onClick={() =>
                  setData((d) => ({
                    ...d,
                    quiz: {
                      ...d.quiz,
                      questions: [
                        ...d.quiz.questions,
                        { id: `q-${Date.now()}`, q: 'Pertanyaan baru?', options: ['Opsi A', 'Opsi B', 'Opsi C', 'Opsi D'], correct: 0 },
                      ],
                    },
                  }))
                }
              >
                ➕ Tambah Pertanyaan
              </Button>

              <p className="pt-2 text-xs font-bold uppercase tracking-wider text-rose-400">Hasil skor (gelar lucu)</p>
              {data.quiz.tiers.map((t, ti) => (
                <div key={ti} className="rounded-2xl border border-pink-100 bg-white/80 p-3 space-y-2">
                  <p className="text-[11px] font-bold text-rose-500">Skor minimal: {t.min}</p>
                  <Input
                    value={t.title}
                    onChange={(e) =>
                      setData((d) => ({ ...d, quiz: { ...d.quiz, tiers: d.quiz.tiers.map((x, j) => (j === ti ? { ...x, title: e.target.value } : x)) } }))
                    }
                    className="border-pink-200"
                  />
                  <Textarea
                    rows={2}
                    value={t.text}
                    onChange={(e) =>
                      setData((d) => ({ ...d, quiz: { ...d.quiz, tiers: d.quiz.tiers.map((x, j) => (j === ti ? { ...x, text: e.target.value } : x)) } }))
                    }
                    className="border-pink-200"
                  />
                </div>
              ))}
            </TabsContent>

            {/* ---- Hadiah ---- */}
            <TabsContent value="hadiah" className="space-y-4">
              {data.gifts.map((g) => (
                <div key={g.id} className="rounded-2xl border border-pink-100 bg-white/80 p-4 space-y-2">
                  <div className="flex gap-2">
                    <Input
                      value={g.emoji}
                      onChange={(e) => setData((d) => ({ ...d, gifts: d.gifts.map((x) => (x.id === g.id ? { ...x, emoji: e.target.value } : x)) }))}
                      className="w-16 text-center"
                      aria-label="Emoji hadiah"
                    />
                    <Input
                      value={g.title}
                      onChange={(e) => setData((d) => ({ ...d, gifts: d.gifts.map((x) => (x.id === g.id ? { ...x, title: e.target.value } : x)) }))}
                      className="flex-1 border-pink-200"
                      placeholder="Nama hadiah"
                    />
                  </div>
                  <Textarea
                    rows={3}
                    value={g.message}
                    onChange={(e) => setData((d) => ({ ...d, gifts: d.gifts.map((x) => (x.id === g.id ? { ...x, message: e.target.value } : x)) }))}
                    className="border-pink-200"
                    placeholder="Pesan romantis saat hadiah dibuka"
                  />
                </div>
              ))}
            </TabsContent>

            {/* ---- Mood & Kangen ---- */}
            <TabsContent value="mood" className="space-y-4">
              {data.moods.map((m) => (
                <div key={m.id} className="rounded-2xl border border-pink-100 bg-white/80 p-4 space-y-2">
                  <div className="flex gap-2">
                    <Input
                      value={m.emoji}
                      onChange={(e) => setData((d) => ({ ...d, moods: d.moods.map((x) => (x.id === m.id ? { ...x, emoji: e.target.value } : x)) }))}
                      className="w-16 text-center"
                      aria-label="Emoji mood"
                    />
                    <Input
                      value={m.label}
                      onChange={(e) => setData((d) => ({ ...d, moods: d.moods.map((x) => (x.id === m.id ? { ...x, label: e.target.value } : x)) }))}
                      className="flex-1 border-pink-200"
                      placeholder="Nama mood"
                    />
                  </div>
                  <Textarea
                    rows={3}
                    value={m.message}
                    onChange={(e) => setData((d) => ({ ...d, moods: d.moods.map((x) => (x.id === m.id ? { ...x, message: e.target.value } : x)) }))}
                    className="border-pink-200"
                    placeholder="Pesan penyemangat"
                  />
                </div>
              ))}
              <Field label="Pesan acak tombol 'Aku Kangen Kamu' (satu pesan per baris)">
                <LinesEditor value={data.missYouMessages} onSave={(lines) => update({ missYouMessages: lines })} rows={6} />
              </Field>
            </TabsContent>

            {/* ---- Impian ---- */}
            <TabsContent value="impian" className="space-y-6">
              <div>
                <p className="mb-2 text-xs font-bold uppercase tracking-wider text-rose-400">🗺️ Tempat impian</p>
                <DreamListEditor
                  items={data.future.places}
                  emptyLabel="catatan kecil..."
                  onChange={(places) => setData((d) => ({ ...d, future: { ...d.future, places } }))}
                />
              </div>
              <div>
                <p className="mb-2 text-xs font-bold uppercase tracking-wider text-rose-400">🎯 Hal yang mau dilakukan</p>
                <DreamListEditor
                  items={data.future.dreams}
                  emptyLabel="catatan kecil..."
                  onChange={(dreams) => setData((d) => ({ ...d, future: { ...d.future, dreams } }))}
                />
              </div>
              <div>
                <p className="mb-2 text-xs font-bold uppercase tracking-wider text-rose-400">🤝 Janji-janji manis</p>
                <DreamListEditor
                  items={data.future.promises}
                  emptyLabel="isi janjinya..."
                  onChange={(promises) => setData((d) => ({ ...d, future: { ...d.future, promises } }))}
                />
              </div>
            </TabsContent>

            {/* ---- Rahasia ---- */}
            <TabsContent value="rahasia" className="space-y-4">
              <Field label="Password halaman rahasia">
                <Input value={data.secretPassword} onChange={(e) => update({ secretPassword: e.target.value })} className="border-pink-200" />
              </Field>
              <Field label="Surat cinta rahasia (pisahkan paragraf dengan baris kosong)">
                <LongTextEditor value={data.secretLetter} onSave={(v) => update({ secretLetter: v })} rows={10} label="Surat rahasia" />
              </Field>
            </TabsContent>

            {/* ---- Penutup ---- */}
            <TabsContent value="penutup" className="space-y-4">
              <Field label="Kalimat besar penutup">
                <LongTextEditor value={data.final.title} onSave={(v) => setData((d) => ({ ...d, final: { ...d.final, title: v } }))} rows={4} label="Kalimat besar" />
              </Field>
              <Field label="Pesan cinta terakhir">
                <LongTextEditor value={data.final.message} onSave={(v) => setData((d) => ({ ...d, final: { ...d.final, message: v } }))} rows={4} label="Pesan akhir" />
              </Field>
              <Field label="Teks tombol terakhir">
                <Input value={data.final.btn} onChange={(e) => setData((d) => ({ ...d, final: { ...d.final, btn: e.target.value } }))} className="border-pink-200" />
              </Field>
              <Field label="Teks setelah tombol ditekan">
                <Input value={data.final.fireworks} onChange={(e) => setData((d) => ({ ...d, final: { ...d.final, fireworks: e.target.value } }))} className="border-pink-200" />
              </Field>
            </TabsContent>

            {/* ---- Musik ---- */}
            <TabsContent value="musik" className="space-y-4">
              <Field label="Nama lagu (yang tampil di pemutar)">
                <Input value={data.songName} onChange={(e) => update({ songName: e.target.value })} className="border-pink-200" />
              </Field>
              <Field label="Ganti lagu dengan file sendiri (mp3/m4a/wav)">
                <label>
                  <input
                    type="file"
                    accept="audio/*"
                    className="hidden"
                    onChange={async (e) => {
                      const f = e.target.files?.[0]
                      e.target.value = ''
                      if (!f) return
                      try {
                        const url = await audioToDataUrl(f)
                        await setMedia('song', url)
                        update({ songName: f.name.replace(/\.[^.]+$/, '') })
                        toast({ title: 'Lagu tersimpan! 🎵', description: 'Buka bagian Our Love Song lalu tekan play.' })
                      } catch {
                        toast({ title: 'Gagal memuat lagu 😢' })
                      }
                    }}
                  />
                  <span className="inline-flex h-10 cursor-pointer items-center rounded-full bg-gradient-to-r from-pink-400 to-rose-400 px-6 text-sm font-bold text-white shadow-md transition hover:scale-105 active:scale-95">
                    📤 Upload Lagu
                  </span>
                </label>
              </Field>
              <Button
                size="sm"
                variant="outline"
                className="rounded-full border-pink-300 text-rose-600 hover:bg-pink-50"
                onClick={() => {
                  void setMedia('song', null)
                  update({ songName: DEFAULT_DATA.songName })
                  toast({ title: 'Kembali ke music box bawaan 🎼' })
                }}
              >
                ♪ Hapus lagu uploadan, pakai music box bawaan
              </Button>
              <p className="text-xs leading-relaxed text-rose-500/70">
                Musik bawaan dibuat langsung oleh browser (music box lembut, bebas hak cipta). Lagu uploadan tersimpan di browser ini.
              </p>
            </TabsContent>

            {/* ---- Data ---- */}
            <TabsContent value="data" className="space-y-4">
              <div className="rounded-2xl border border-pink-100 bg-white/80 p-4 text-sm text-rose-800">
                <p>📸 Foto di galeri: <b>{data.gallery.length}</b></p>
                <p>💗 Alasan cinta: <b>{data.reasons.length}</b></p>
                <p>💌 Surat: <b>{data.letters.length}</b> &nbsp;|&nbsp; 🎀 Pertanyaan kuis: <b>{data.quiz.questions.length}</b></p>
                <p>💾 Total data tersimpan di browser ini: <b>± {storageSize} MB</b></p>
              </div>
              <div className="flex flex-wrap gap-3">
                <Button onClick={exportData} className="rounded-full bg-gradient-to-r from-pink-400 to-rose-400 text-white hover:from-pink-500 hover:to-rose-500">
                  📤 Export Data (backup .json)
                </Button>
                <label>
                  <input
                    type="file"
                    accept="application/json"
                    className="hidden"
                    onChange={(e) => {
                      void importData(e.target.files?.[0])
                      e.target.value = ''
                    }}
                  />
                  <span className="inline-flex h-10 cursor-pointer items-center rounded-full border border-pink-300 bg-white/80 px-5 text-sm font-bold text-rose-600 transition hover:bg-pink-50 active:scale-95">
                    {importing ? 'Mengimpor... ⏳' : '📥 Import Data'}
                  </span>
                </label>
              </div>
              <Button
                variant="destructive"
                className="rounded-full bg-rose-600 text-white hover:bg-rose-700"
                onClick={() => setConfirmReset(true)}
              >
                ♻️ Reset Semua Konten ke Awal
              </Button>
              <p className="text-xs leading-relaxed text-rose-500/70">
                Reset akan menghapus semua foto, caption, dan perubahan teks di browser ini — semuanya kembali seperti pertama kali dibuat.
                Kalau mau pindah perangkat, pakai Export dulu ya!
              </p>
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>

      <AlertDialog open={confirmReset} onOpenChange={setConfirmReset}>
        <AlertDialogContent className="rounded-3xl border-pink-200 bg-[#FFF7F9]">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-rose-800">Reset semua konten? 🥺</AlertDialogTitle>
            <AlertDialogDescription className="text-rose-700/80">
              Semua foto, caption, dan teks yang sudah kamu ubah akan kembali ke bawaan. Tindakan ini tidak bisa dibatalkan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-full border-pink-200 text-rose-600">Batal</AlertDialogCancel>
            <AlertDialogAction
              className="rounded-full bg-rose-600 text-white hover:bg-rose-700"
              onClick={() => {
                void resetAll()
                setConfirmReset(false)
                toast({ title: 'Dunia kecil kembali ke awal 🌱', description: 'Semua konten sudah direset ke bawaan.' })
              }}
            >
              Ya, Reset
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Dialog>
  )
}
