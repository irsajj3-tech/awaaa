'use client'

import { Button } from '@/components/ui/button'
import { burstFromElement } from '@/lib/adhwa/burst'
import { cn } from '@/lib/utils'
import { forwardRef } from 'react'

interface CuteButtonProps extends React.ComponentProps<typeof Button> {
  burstCount?: number
}

export const CuteButton = forwardRef<HTMLButtonElement, CuteButtonProps>(
  ({ className, onClick, burstCount = 10, ...props }, ref) => {
    return (
      <Button
        ref={ref}
        onClick={(e) => {
          burstFromElement(e.currentTarget, { count: burstCount, power: 120 })
          onClick?.(e)
        }}
        className={cn(
          'rounded-full font-bold shadow-[0_8px_24px_rgba(231,84,128,0.35)] transition-all',
          'bg-gradient-to-r from-pink-400 to-rose-400 text-white hover:from-pink-500 hover:to-rose-500 hover:shadow-[0_10px_30px_rgba(231,84,128,0.5)]',
          'active:scale-90 hover:scale-105',
          className
        )}
        {...props}
      />
    )
  }
)
CuteButton.displayName = 'CuteButton'

interface SoftButtonProps extends React.ComponentProps<typeof Button> {
  burstCount?: number
}

export const SoftButton = forwardRef<HTMLButtonElement, SoftButtonProps>(
  ({ className, onClick, burstCount = 6, ...props }, ref) => (
    <Button
      ref={ref}
      onClick={(e) => {
        burstFromElement(e.currentTarget, { count: burstCount, power: 90, size: 16 })
        onClick?.(e)
      }}
      className={cn(
        'rounded-full font-bold text-rose-600 shadow-md transition-all active:scale-90 hover:scale-105',
        'border border-pink-200 bg-white/70 backdrop-blur-md hover:bg-white',
        className
      )}
      {...props}
    />
  )
)
SoftButton.displayName = 'SoftButton'
