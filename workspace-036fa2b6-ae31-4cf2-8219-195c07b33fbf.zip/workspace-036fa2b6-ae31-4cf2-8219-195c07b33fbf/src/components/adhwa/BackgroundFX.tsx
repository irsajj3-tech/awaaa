'use client'

import { useMemo } from 'react'

const PETALS = ['🌸', '🌷', '💮', '✨', '💫', '🩷']
const STARS = ['✦', '✧', '·']

export function BackgroundFX() {
  const petals = useMemo(
    () =>
      Array.from({ length: 16 }, (_, i) => ({
        id: i,
        emoji: PETALS[i % PETALS.length],
        left: Math.random() * 100,
        delay: Math.random() * 18,
        dur: 14 + Math.random() * 16,
        size: 14 + Math.random() * 16,
        swayDur: 2.6 + Math.random() * 2.4,
        opacity: 0.5 + Math.random() * 0.4,
      })),
    []
  )

  const sparkles = useMemo(
    () =>
      Array.from({ length: 18 }, (_, i) => ({
        id: i,
        char: STARS[i % STARS.length],
        top: Math.random() * 100,
        left: Math.random() * 100,
        delay: Math.random() * 4,
        dur: 2 + Math.random() * 3,
        size: 8 + Math.random() * 10,
      })),
    []
  )

  return (
    <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
      {/* soft gradient blobs */}
      <div className="anim-blob absolute -left-24 top-10 h-80 w-80 rounded-full bg-pink-300/40 blur-3xl" />
      <div
        className="anim-blob absolute right-[-6rem] top-1/4 h-96 w-96 rounded-full bg-rose-200/40 blur-3xl"
        style={{ animationDelay: '-8s' }}
      />
      <div
        className="anim-blob absolute bottom-[-4rem] left-1/4 h-72 w-72 rounded-full bg-fuchsia-200/30 blur-3xl"
        style={{ animationDelay: '-16s' }}
      />

      {/* twinkling stars */}
      {sparkles.map((s) => (
        <span
          key={`s-${s.id}`}
          className="anim-twinkle absolute text-white/80"
          style={{
            top: `${s.top}%`,
            left: `${s.left}%`,
            fontSize: s.size,
            animationDelay: `${s.delay}s`,
            animationDuration: `${s.dur}s`,
          }}
        >
          {s.char}
        </span>
      ))}

      {/* falling petals */}
      {petals.map((p) => (
        <span
          key={`p-${p.id}`}
          className="anim-fall absolute -top-12"
          style={{
            left: `${p.left}%`,
            animationDelay: `-${p.delay}s`,
            animationDuration: `${p.dur}s`,
          }}
        >
          <span
            className="anim-sway inline-block"
            style={{
              fontSize: p.size,
              opacity: p.opacity,
              animationDuration: `${p.swayDur}s`,
            }}
          >
            {p.emoji}
          </span>
        </span>
      ))}
    </div>
  )
}
