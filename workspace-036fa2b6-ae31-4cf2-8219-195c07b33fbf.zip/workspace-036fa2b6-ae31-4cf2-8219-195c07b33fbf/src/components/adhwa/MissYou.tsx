'use client'

import { useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Section } from './Section'
import { useAdhwa } from '@/lib/adhwa/store'
import { burstHearts } from '@/lib/adhwa/burst'

export function MissYou() {
  const messages = useAdhwa((s) => s.data.missYouMessages)
  const count = useAdhwa((s) => s.data.missYouCount)
  const herName = useAdhwa((s) => s.data.herName)
  const update = useAdhwa((s) => s.update)
  const [msg, setMsg] = useState<string | null>(null)
  const [mega, setMega] = useState(false)
  const lastIdx = useRef(-1)

  const press = (e: React.MouseEvent<HTMLButtonElement>) => {
    const next = (count ?? 0) + 1
    update({ missYouCount: next })

    // big heart explosion from the button
    const r = e.currentTarget.getBoundingClientRect()
    const cx = r.left + r.width / 2
    const cy = r.top + r.height / 2
    burstHearts(cx, cy, { count: 26, power: 240, size: 26 })

    if (next % 5 === 0) {
      setMega(true)
      setTimeout(() => setMega(false), 1600)
      for (let i = 0; i < 6; i++) {
        setTimeout(
          () =>
            burstHearts(
              Math.random() * window.innerWidth,
              Math.random() * window.innerHeight * 0.7 + 60,
              { count: 12, power: 220 }
            ),
          i * 200
        )
      }
    }

    // random message without immediate repeat
    if (messages.length > 0) {
      let idx = Math.floor(Math.random() * messages.length)
      if (messages.length > 1 && idx === lastIdx.current) {
        idx = (idx + 1) % messages.length
      }
      lastIdx.current = idx
      setMsg(messages[idx])
    }
  }

  return (
    <Section
      id="missyou"
      emoji="🐻"
      kicker="kapan pun kamu butuh, tekan ini"
      title="Miss You Button"
      sub={`Tombol spesial buat ${herName}. Setiap ditekan, dunia kecil ini meledakkan hati dan ngasih balasan kangen dariku.`}
    >
      <div className="mx-auto flex max-w-md flex-col items-center">
        <motion.button
          onClick={press}
          whileTap={{ scale: 0.88 }}
          className="anim-heartbeat relative flex h-44 w-44 flex-col items-center justify-center rounded-full bg-gradient-to-br from-pink-400 via-rose-400 to-rose-500 text-white shadow-[0_20px_60px_rgba(231,84,128,0.5)] transition-transform hover:scale-105 sm:h-52 sm:w-52"
          aria-label="Aku Kangen Kamu"
        >
          <span className="text-4xl">🐻</span>
          <span className="font-display mt-2 text-lg font-extrabold">Aku Kangen Kamu</span>
          <span className="text-xs opacity-90">tekan aku! 🥺</span>
        </motion.button>

        <p className="mt-5 text-sm font-bold text-rose-600">
          Tombol sudah ditekan <span className="font-display text-lg text-rose-500">{count ?? 0}×</span> 💗
        </p>

        <AnimatePresence mode="wait">
          {msg && (
            <motion.div
              key={msg}
              initial={{ opacity: 0, y: 24, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ type: 'spring', stiffness: 240, damping: 18 }}
              className="glass mt-5 rounded-3xl px-6 py-5 text-center"
            >
              <span className="text-2xl">💌</span>
              <p className="font-script mt-1 text-xl leading-relaxed text-rose-800">&ldquo;{msg}&rdquo;</p>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {mega && (
            <motion.div
              initial={{ opacity: 0, scale: 0.5, rotate: -6 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              exit={{ opacity: 0, scale: 0.7 }}
              transition={{ type: 'spring', stiffness: 260, damping: 14 }}
              className="pointer-events-none fixed inset-x-4 top-1/4 z-[75] text-center"
            >
              <p className="font-display text-3xl font-extrabold text-transparent sm:text-5xl"
                style={{
                  backgroundImage: 'linear-gradient(90deg,#E75480,#FF9BC0,#B76E79)',
                  WebkitBackgroundClip: 'text',
                  backgroundClip: 'text',
                }}
              >
                MEGA KANGEN MODE! 🐻💖
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </Section>
  )
}
