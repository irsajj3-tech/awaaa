'use client'

import { motion } from 'framer-motion'
import { useUi } from '@/lib/adhwa/store'
import { music } from '@/lib/adhwa/music'

export function TopBar() {
  const musicOn = useUi((s) => s.musicOn)
  const setMusicOn = useUi((s) => s.setMusicOn)
  const setAdminOpen = useUi((s) => s.setAdminOpen)

  const toggleMusic = async () => {
    const playing = await music.toggle()
    setMusicOn(playing)
  }

  return (
    <div className="fixed right-3 top-3 z-50 flex gap-2">
      <motion.button
        whileTap={{ scale: 0.85 }}
        onClick={() => void toggleMusic()}
        className={`glass flex h-11 items-center gap-2 rounded-full px-4 text-sm font-bold shadow-lg transition-colors ${
          musicOn ? 'text-rose-600' : 'text-rose-400/80'
        }`}
        aria-label={musicOn ? 'Matikan musik latar' : 'Nyalakan musik latar'}
        title={musicOn ? 'Musik: ON' : 'Musik: OFF'}
      >
        <motion.span
          animate={musicOn ? { rotate: [0, -12, 12, -8, 8, 0] } : {}}
          transition={{ duration: 1.2, repeat: musicOn ? Infinity : 0, repeatDelay: 1.5 }}
          className="text-lg"
        >
          {musicOn ? '🔊' : '🔇'}
        </motion.span>
        <span className="hidden sm:inline">Musik {musicOn ? 'ON' : 'OFF'}</span>
      </motion.button>

      <motion.button
        whileTap={{ scale: 0.85 }}
        onClick={() => setAdminOpen(true)}
        className="glass flex h-11 w-11 items-center justify-center rounded-full text-lg shadow-lg transition-colors hover:text-rose-600"
        aria-label="Buka mode edit (admin)"
        title="Mode Edit / Admin 🔐"
      >
        🔧
      </motion.button>
    </div>
  )
}
