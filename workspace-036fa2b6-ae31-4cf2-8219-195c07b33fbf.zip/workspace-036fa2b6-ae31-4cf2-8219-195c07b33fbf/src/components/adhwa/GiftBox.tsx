'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Section } from './Section'
import { SoftButton } from './CuteButton'
import { useAdhwa } from '@/lib/adhwa/store'
import { burstFromElement } from '@/lib/adhwa/burst'

export function GiftBox() {
  const gifts = useAdhwa((s) => s.data.gifts)
  const [openId, setOpenId] = useState<string | null>(null)
  const [justOpened, setJustOpened] = useState<string | null>(null)

  const open = (id: string, ev: React.MouseEvent<HTMLButtonElement>) => {
    if (openId) return
    burstFromElement(ev.currentTarget, { count: 16, power: 180, size: 22 })
    setOpenId(id)
    setJustOpened(id)
    setTimeout(() => setJustOpened(null), 1200)
  }

  return (
    <Section
      id="gifts"
      emoji="🎁"
      kicker="klik kotaknya, jangan malu-malu"
      title="Virtual Gift Box"
      sub="Lima kotak hadiah kecil dari aku. Setiap kotak berisi hal manis yang beda — peluk, cium, bunga, surat, dan satu kejutan rahasia."
    >
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {gifts.map((g, i) => {
          const isOpen = openId === g.id
          return (
            <div key={g.id} className="mx-auto w-full max-w-[240px]">
              <AnimatePresence mode="wait">
                {!isOpen ? (
                  <motion.button
                    key={`box-${g.id}`}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={
                      justOpened === g.id
                        ? { rotate: [0, -8, 8, -8, 8, 0], scale: 1.15 }
                        : { rotate: 0, scale: 1 }
                    }
                    exit={{ opacity: 0, scale: 0.6, y: -20 }}
                    transition={{ duration: 0.6 }}
                    whileHover={{ scale: 1.08, y: -4 }}
                    whileTap={{ scale: 0.92 }}
                    onClick={(e) => open(g.id, e)}
                    className="glass flex w-full flex-col items-center rounded-3xl px-4 py-6"
                    aria-label={`Buka ${g.title}`}
                  >
                    <motion.span
                      className="text-5xl"
                      animate={{ y: [0, -6, 0] }}
                      transition={{ duration: 1.6 + i * 0.2, repeat: Infinity }}
                    >
                      {g.emoji}
                    </motion.span>
                    <p className="mt-3 text-center text-sm font-bold text-rose-800">{g.title}</p>
                    <p className="mt-1 text-[11px] text-rose-500/80">tap buat buka 🎀</p>
                  </motion.button>
                ) : (
                  <motion.div
                    key={`msg-${g.id}`}
                    initial={{ opacity: 0, y: 24, scale: 0.85 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    transition={{ type: 'spring', stiffness: 220, damping: 16 }}
                    className="glass flex w-full flex-col rounded-3xl px-4 py-6"
                  >
                    <motion.span
                      className="text-center text-5xl"
                      animate={{ y: [0, -10, 0] }}
                      transition={{ duration: 1.4, repeat: Infinity }}
                    >
                      {g.emoji}
                    </motion.span>
                    <p className="mt-3 text-center text-sm font-bold text-rose-800">{g.title}</p>
                    <p className="mt-2 text-center text-[13px] leading-relaxed text-rose-900/90">{g.message}</p>
                    <SoftButton className="mt-4 mx-auto" size="sm" onClick={() => setOpenId(null)}>
                      Tutup Hadiahnya
                    </SoftButton>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )
        })}
      </div>
    </Section>
  )
}
