'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Section, GlassCard } from './Section'
import { useAdhwa } from '@/lib/adhwa/store'
import { burstFromElement } from '@/lib/adhwa/burst'

export function Mood() {
  const moods = useAdhwa((s) => s.data.moods)
  const [active, setActive] = useState<string | null>(null)
  const mood = moods.find((m) => m.id === active)

  return (
    <Section
      id="mood"
      emoji="💓"
      kicker="ceritain dong, kamu lagi gimana?"
      title="Mood Checker"
      sub="Pilih mood kamu hari ini, dan dunia kecil ini bakal ngasih pesan yang pas buat kamu."
    >
      <div className="mx-auto max-w-2xl">
        <div className="flex flex-wrap justify-center gap-3">
          {moods.map((m, i) => (
            <motion.button
              key={m.id}
              whileHover={{ scale: 1.08, y: -3 }}
              whileTap={{ scale: 0.9 }}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              onClick={(e) => {
                setActive(m.id)
                burstFromElement(e.currentTarget, { count: 8, power: 100, size: 16 })
              }}
              className={`flex items-center gap-2 rounded-full border px-5 py-3 text-sm font-bold transition-all ${
                active === m.id
                  ? 'border-pink-400 bg-pink-200/90 text-rose-900 shadow-[0_8px_20px_rgba(231,84,128,0.35)]'
                  : 'border-pink-200 bg-white/70 text-rose-700 hover:bg-pink-50'
              }`}
            >
              <span className="text-xl">{m.emoji}</span>
              {m.label}
            </motion.button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          {mood && (
            <motion.div
              key={mood.id}
              initial={{ opacity: 0, y: 24, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ type: 'spring', stiffness: 220, damping: 18 }}
              className="mt-8"
            >
              <GlassCard className="text-center">
                <motion.span
                  className="inline-block text-5xl"
                  animate={{ y: [0, -8, 0], rotate: [0, 6, -6, 0] }}
                  transition={{ duration: 1.8, repeat: Infinity }}
                >
                  {mood.emoji}
                </motion.span>
                <p className="font-script mt-3 text-2xl text-rose-700">{mood.label}</p>
                <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-rose-900/90">{mood.message}</p>
                <p className="mt-4 text-xs font-semibold text-rose-500/80">
                  apa pun mood-nya, aku tetap di sini ya 💗
                </p>
              </GlassCard>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </Section>
  )
}
