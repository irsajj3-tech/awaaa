'use client'

import { useEffect, useMemo, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Section, GlassCard } from './Section'
import { SoftButton } from './CuteButton'
import { Input } from '@/components/ui/input'
import { useAdhwa } from '@/lib/adhwa/store'
import { burstHearts } from '@/lib/adhwa/burst'

function diffParts(fromMs: number, nowMs: number) {
  const diff = Math.max(0, nowMs - fromMs)
  const days = Math.floor(diff / 86_400_000)
  const hours = Math.floor((diff % 86_400_000) / 3_600_000)
  const minutes = Math.floor((diff % 3_600_000) / 60_000)
  const seconds = Math.floor((diff % 60_000) / 1000)
  return { days, hours, minutes, seconds }
}

export function LoveCounter() {
  const anniversary = useAdhwa((s) => s.data.anniversary)
  const counterTitle = useAdhwa((s) => s.data.counterTitle)
  const herName = useAdhwa((s) => s.data.herName)
  const update = useAdhwa((s) => s.update)
  const [now, setNow] = useState<number | null>(null)
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(anniversary)

  useEffect(() => {
    const id = requestAnimationFrame(() => setNow(Date.now()))
    const t = setInterval(() => setNow(Date.now()), 1000)
    return () => {
      cancelAnimationFrame(id)
      clearInterval(t)
    }
  }, [])

  const fromMs = useMemo(() => new Date(anniversary).getTime(), [anniversary])
  const valid = !Number.isNaN(fromMs)
  const parts = now !== null && valid ? diffParts(fromMs, now) : null

  const dateLabel = valid
    ? new Date(fromMs).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })
    : 'tanggal belum diatur'

  const saveDate = () => {
    const t = new Date(draft).getTime()
    if (Number.isNaN(t)) return
    update({ anniversary: draft })
    setEditing(false)
    burstHearts(window.innerWidth / 2, window.innerHeight / 3, { count: 18, power: 200 })
  }

  return (
    <Section id="counter" emoji="⏳" kicker="detik demi detik, semakin sayang" title={counterTitle}>
      <GlassCard className="mx-auto max-w-3xl text-center">
        <p className="text-sm text-rose-700/80">
          Kita sudah bersama sejak{' '}
          <span className="font-script text-lg text-rose-600">{dateLabel}</span>{' '}
          <button
            aria-label="Ubah tanggal jadian"
            className="rounded-full px-1 transition hover:bg-pink-100"
            onClick={() => {
              setDraft(anniversary)
              setEditing((v) => !v)
            }}
          >
            ✏️
          </button>
        </p>

        <AnimatePresence>
          {editing && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                <Input
                  type="datetime-local"
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  className="w-64 border-pink-200 bg-white/80 text-rose-800 focus-visible:ring-pink-300"
                />
                <SoftButton onClick={saveDate}>Simpan Tanggal 💗</SoftButton>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {parts ? (
          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              { label: 'Hari', value: parts.days },
              { label: 'Jam', value: parts.hours },
              { label: 'Menit', value: parts.minutes },
              { label: 'Detik', value: parts.seconds },
            ].map((u) => (
              <div key={u.label} className="rounded-2xl border border-pink-100 bg-white/70 px-4 py-5">
                <p className="font-display text-3xl font-extrabold tabular-nums text-rose-600 sm:text-4xl">
                  {String(u.value).padStart(2, '0')}
                </p>
                <p className="mt-1 text-xs font-bold uppercase tracking-wider text-rose-500/80">{u.label}</p>
              </div>
            ))}
          </div>
        ) : (
          <p className="mt-6 text-sm text-rose-600/80">Menghitung detik demi detik... ⏳</p>
        )}

        <p className="font-script mt-6 text-xl text-rose-700">
          dan setiap detik itu berisi sayang buat {herName} 💗
        </p>
        <motion.span
          className="mt-2 inline-block text-3xl"
          animate={{ scale: [1, 1.25, 1] }}
          transition={{ duration: 1.2, repeat: Infinity }}
        >
          💖
        </motion.span>
      </GlassCard>
    </Section>
  )
}
