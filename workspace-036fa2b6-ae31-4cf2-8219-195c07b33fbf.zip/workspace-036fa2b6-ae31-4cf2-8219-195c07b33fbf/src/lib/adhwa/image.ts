// Image helpers: compress uploaded photos to keep storage small,
// and generate cute pink placeholder images.

export async function fileToDataUrl(file: File, maxDim = 1280, quality = 0.82): Promise<string> {
  const raw = await new Promise<string>((resolve, reject) => {
    const fr = new FileReader()
    fr.onload = () => resolve(String(fr.result))
    fr.onerror = () => reject(fr.error)
    fr.readAsDataURL(file)
  })

  // Try to downscale with canvas (fall back to raw dataURL if it fails, e.g. HEIC)
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image()
      el.onload = () => resolve(el)
      el.onerror = reject
      el.src = raw
    })
    const scale = Math.min(1, maxDim / Math.max(img.naturalWidth, img.naturalHeight))
    if (scale < 1 || raw.length > 400_000) {
      const canvas = document.createElement('canvas')
      canvas.width = Math.round(img.naturalWidth * scale)
      canvas.height = Math.round(img.naturalHeight * scale)
      const ctx = canvas.getContext('2d')
      if (ctx) {
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
        return canvas.toDataURL('image/jpeg', quality)
      }
    }
  } catch {
    /* fallback below */
  }
  return raw
}

export async function audioToDataUrl(file: File): Promise<string> {
  return new Promise<string>((resolve, reject) => {
    const fr = new FileReader()
    fr.onload = () => resolve(String(fr.result))
    fr.onerror = () => reject(fr.error)
    fr.readAsDataURL(file)
  })
}

const PALETTES: Array<[string, string]> = [
  ['#FFE1EC', '#FFB7C5'],
  ['#FFF0F5', '#FFC8DD'],
  ['#FFE4EE', '#F8A8C2'],
  ['#FFF7F9', '#FFD3E0'],
  ['#FFE9F1', '#F49FBF'],
  ['#FDEFF4', '#EFB6CF'],
]

const EMOJIS = ['🌸', '💖', '🌷', '🎀', '✨', '🐰', '💝', '🦋', '🍓', '☁️']

export function placeholderPhoto(index: number, label = 'Foto Kenangan'): string {
  const [c1, c2] = PALETTES[index % PALETTES.length]
  const emoji = EMOJIS[index % EMOJIS.length]
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="750" viewBox="0 0 600 750">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="${c1}"/>
      <stop offset="100%" stop-color="${c2}"/>
    </linearGradient>
  </defs>
  <rect width="600" height="750" fill="url(#g)"/>
  <circle cx="120" cy="140" r="70" fill="#ffffff" opacity="0.35"/>
  <circle cx="500" cy="620" r="90" fill="#ffffff" opacity="0.30"/>
  <circle cx="480" cy="120" r="40" fill="#ffffff" opacity="0.4"/>
  <text x="300" y="370" font-size="120" text-anchor="middle">${emoji}</text>
  <text x="300" y="480" font-family="Georgia, serif" font-style="italic" font-size="40" fill="#B3455F" text-anchor="middle">${label}</text>
  <text x="300" y="530" font-family="Georgia, serif" font-size="22" fill="#C9708C" text-anchor="middle">upload foto favoritmu 📸</text>
</svg>`
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg)
}
