'use client'

import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'
import { useEffect, useState } from 'react'
import { DEFAULT_DATA } from './defaults'
import type { AdhwaData } from './types'
import { idbClear, idbDelete, idbGetAll, idbSet } from './idb'

interface AdhwaStore {
  data: AdhwaData
  media: Record<string, string>
  mediaReady: boolean
  update: (patch: Partial<AdhwaData>) => void
  setData: (fn: (d: AdhwaData) => AdhwaData) => void
  setMedia: (key: string, val: string | null) => Promise<void>
  hydrateMedia: () => Promise<void>
  importAll: (data: AdhwaData, media: Record<string, string>) => Promise<void>
  resetAll: () => Promise<void>
}

export const useAdhwa = create<AdhwaStore>()(
  persist(
    (set, get) => ({
      data: DEFAULT_DATA,
      media: {},
      mediaReady: false,
      update: (patch) => set((s) => ({ data: { ...s.data, ...patch } })),
      setData: (fn) => set((s) => ({ data: fn(s.data) })),
      setMedia: async (key, val) => {
        set((s) => {
          const media = { ...s.media }
          if (val === null) delete media[key]
          else media[key] = val
          return { media }
        })
        if (val === null) await idbDelete(key)
        else await idbSet(key, val)
      },
      hydrateMedia: async () => {
        const all = await idbGetAll()
        set({ media: all, mediaReady: true })
      },
      importAll: async (data, media) => {
        await idbClear()
        for (const [k, v] of Object.entries(media)) {
          await idbSet(k, v)
        }
        set({ data, media })
      },
      resetAll: async () => {
        await idbClear()
        set({ data: structuredClone(DEFAULT_DATA), media: {} })
      },
    }),
    {
      name: 'adhwa-world-v1',
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({ data: s.data }) as unknown as AdhwaStore,
    }
  )
)

// Simple global UI state (admin panel, music toggle, welcome gate)
interface UiStore {
  adminOpen: boolean
  setAdminOpen: (v: boolean) => void
  musicOn: boolean
  setMusicOn: (v: boolean) => void
}

export const useUi = create<UiStore>((set) => ({
  adminOpen: false,
  setAdminOpen: (v) => set({ adminOpen: v }),
  musicOn: false,
  setMusicOn: (v) => set({ musicOn: v }),
}))

export function useHasMounted(): boolean {
  const [mounted, setMounted] = useState(false)
  useEffect(() => {
    const id = requestAnimationFrame(() => setMounted(true))
    return () => cancelAnimationFrame(id)
  }, [])
  return mounted
}

export function getMediaKeyForPhoto(id: string) {
  return `photo:${id}`
}

export { DEFAULT_DATA }
export type { AdhwaData }
