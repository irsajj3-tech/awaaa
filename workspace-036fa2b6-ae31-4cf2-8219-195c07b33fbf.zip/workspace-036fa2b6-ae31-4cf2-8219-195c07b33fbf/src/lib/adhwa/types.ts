export interface Letter {
  id: string
  title: string
  body: string
}

export interface QuizQuestion {
  id: string
  q: string
  options: string[]
  correct: number
}

export interface QuizTier {
  min: number
  title: string
  text: string
}

export interface Gift {
  id: string
  emoji: string
  title: string
  message: string
}

export interface MoodItem {
  id: string
  emoji: string
  label: string
  message: string
}

export interface DreamItem {
  id: string
  emoji: string
  title: string
  note: string
}

export interface GalleryItem {
  id: string
  caption: string
}

export interface AdhwaData {
  siteTitle: string
  herName: string
  anniversary: string // format: YYYY-MM-DDTHH:mm (datetime-local)
  secretPassword: string
  welcome: { title: string; sub: string; btn: string }
  hero: { title: string; quote: string }
  counterTitle: string
  gallery: GalleryItem[]
  reasons: string[]
  letters: Letter[]
  quiz: { title: string; questions: QuizQuestion[]; tiers: QuizTier[] }
  gifts: Gift[]
  missYouMessages: string[]
  missYouCount: number
  future: { title: string; places: DreamItem[]; dreams: DreamItem[]; promises: DreamItem[] }
  secretLetter: string
  moods: MoodItem[]
  songName: string
  final: { title: string; message: string; btn: string; fireworks: string }
}
