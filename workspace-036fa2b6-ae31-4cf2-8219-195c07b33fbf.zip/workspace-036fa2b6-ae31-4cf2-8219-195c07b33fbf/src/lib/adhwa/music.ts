// Music engine for "A Little World For Adhwa".
// - Default source: a soft original "music box" lullaby synthesized with Web Audio API
//   (royalty-free, generated live in the browser).
// - Custom source: user-uploaded audio file (dataURL) played via <audio> element.
// - A shared AnalyserNode feeds the visualizer.
// Nothing autoplays: everything starts from a user gesture.

export type MusicSource = 'synth' | 'custom'

const BPM = 72
const BEAT = 60 / BPM

type NoteEvent = [beat: number, midi: number, lenBeats: number]

// A gentle original melody over C - G/B - Am - F (48 beats ≈ 40s loop).
const MELODY: NoteEvent[] = [
  [0, 72, 1], [1, 76, 1], [2, 79, 1], [3, 84, 2],
  [5, 83, 1], [6, 79, 2], [8, 76, 1], [9, 72, 2],
  [12, 69, 1], [13, 72, 1], [14, 76, 2], [16, 72, 1], [17, 69, 2],
  [20, 65, 1], [21, 69, 1], [22, 72, 2], [24, 76, 1], [25, 74, 1], [26, 72, 3],
  [28, 72, 1], [29, 76, 1], [30, 79, 1], [31, 84, 2],
  [33, 83, 1], [34, 79, 2], [36, 76, 1], [37, 72, 2],
  [40, 76, 1], [41, 74, 1], [42, 72, 1], [43, 69, 2],
  [45, 67, 1], [46, 69, 1], [47, 72, 3],
]

const BASS: NoteEvent[] = [
  [0, 48, 3.6], [4, 55, 3.6], [8, 57, 3.6], [12, 53, 3.6],
  [16, 48, 3.6], [20, 55, 3.6], [24, 57, 3.6], [28, 53, 3.6],
  [32, 48, 3.6], [36, 55, 3.6], [40, 57, 3.6], [44, 53, 3.2],
]

const PADS: Array<[beat: number, chordMidis: number[]]> = [
  [0, [48, 52, 55]], [4, [55, 59, 62]], [8, [45, 52, 57]], [12, [41, 48, 53]],
  [16, [48, 52, 55]], [20, [55, 59, 62]], [24, [45, 52, 57]], [28, [41, 48, 53]],
  [32, [48, 52, 55]], [36, [55, 59, 62]], [40, [45, 52, 57]], [44, [41, 48, 53]],
]

const LOOP_BEATS = 48
const midiToFreq = (m: number) => 440 * Math.pow(2, (m - 69) / 12)

class MusicEngine {
  private ctx: AudioContext | null = null
  private master: GainNode | null = null
  private dryBus: GainNode | null = null
  private analyser: AnalyserNode | null = null
  private audioEl: HTMLAudioElement | null = null
  private mediaSrc: MediaElementAudioSourceNode | null = null
  private timer: ReturnType<typeof setInterval> | null = null
  private nextLoopAt = 0
  private synthPlaying = false
  private volume = 0.6
  playing = false
  source: MusicSource = 'synth'
  customUrl: string | null = null

  private ensureCtx() {
    if (this.ctx) return
    const AC: typeof AudioContext =
      window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
    this.ctx = new AC()
    this.master = this.ctx.createGain()
    this.master.gain.value = this.volume
    this.analyser = this.ctx.createAnalyser()
    this.analyser.fftSize = 128
    this.analyser.smoothingTimeConstant = 0.78

    // dreamy feedback delay bus
    this.dryBus = this.ctx.createGain()
    const delay = this.ctx.createDelay(1.2)
    delay.delayTime.value = 0.42
    const fb = this.ctx.createGain()
    fb.gain.value = 0.3
    const wet = this.ctx.createGain()
    wet.gain.value = 0.24
    this.dryBus.connect(this.master)
    this.dryBus.connect(delay)
    delay.connect(fb)
    fb.connect(delay)
    delay.connect(wet)
    wet.connect(this.master)

    this.master.connect(this.analyser)
    this.analyser.connect(this.ctx.destination)
  }

  private playNote(
    freq: number,
    start: number,
    dur: number,
    gainVal: number,
    type: OscillatorType,
    detune = 0
  ) {
    if (!this.ctx || !this.dryBus) return
    const osc = this.ctx.createOscillator()
    osc.type = type
    osc.frequency.value = freq
    osc.detune.value = detune
    const g = this.ctx.createGain()
    g.gain.setValueAtTime(0.0001, start)
    g.gain.exponentialRampToValueAtTime(gainVal, start + 0.02)
    g.gain.exponentialRampToValueAtTime(0.0001, start + Math.max(0.25, dur * 0.95))
    osc.connect(g)
    g.connect(this.dryBus)
    osc.start(start)
    osc.stop(start + dur + 0.1)
  }

  private scheduleLoop(loopStart: number) {
    // melody (music-box style: sine + soft overtone)
    for (const [beat, midi, len] of MELODY) {
      const t = loopStart + beat * BEAT
      const d = len * BEAT
      const f = midiToFreq(midi)
      this.playNote(f, t, d, 0.16, 'sine')
      this.playNote(f * 2, t, d * 0.8, 0.05, 'sine', 4)
      this.playNote(f, t, d, 0.1, 'triangle', -6)
    }
    // bass
    for (const [beat, midi, len] of BASS) {
      const t = loopStart + beat * BEAT
      this.playNote(midiToFreq(midi), t, len * BEAT, 0.1, 'triangle')
    }
    // soft pads
    for (const [beat, chord] of PADS) {
      const t = loopStart + beat * BEAT
      for (const midi of chord) {
        this.playNote(midiToFreq(midi), t, BEAT * 4, 0.035, 'sine', 2)
      }
    }
  }

  private startSynth() {
    if (!this.ctx) return
    this.synthPlaying = true
    this.nextLoopAt = this.ctx.currentTime + 0.15
    const tick = () => {
      if (!this.ctx || !this.synthPlaying) return
      const now = this.ctx.currentTime
      while (this.nextLoopAt < now + 0.6) {
        this.scheduleLoop(this.nextLoopAt)
        this.nextLoopAt += LOOP_BEATS * BEAT
      }
    }
    tick()
    this.timer = setInterval(tick, 200)
  }

  private stopSynth() {
    this.synthPlaying = false
    if (this.timer) {
      clearInterval(this.timer)
      this.timer = null
    }
  }

  private ensureCustom() {
    if (!this.ctx || !this.master) return
    if (!this.audioEl) {
      this.audioEl = new Audio()
      this.audioEl.loop = true
      this.audioEl.preload = 'auto'
      this.mediaSrc = this.ctx.createMediaElementSource(this.audioEl)
      this.mediaSrc.connect(this.master)
    }
    if (this.audioEl.src !== this.customUrl) {
      this.audioEl.src = this.customUrl ?? ''
    }
  }

  async play() {
    this.ensureCtx()
    if (!this.ctx) return
    if (this.ctx.state === 'suspended') await this.ctx.resume()
    if (this.source === 'custom' && this.customUrl) {
      this.stopSynth()
      this.ensureCustom()
      await this.audioEl?.play()
    } else {
      this.source = 'synth'
      this.stopSynth()
      this.startSynth()
    }
    this.playing = true
  }

  pause() {
    if (this.source === 'custom') {
      this.audioEl?.pause()
    } else {
      this.stopSynth()
    }
    this.playing = false
  }

  async toggle(): Promise<boolean> {
    if (this.playing) {
      this.pause()
    } else {
      await this.play()
    }
    return this.playing
  }

  setVolume(v: number) {
    this.volume = Math.max(0, Math.min(1, v))
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(this.volume, this.ctx.currentTime, 0.05)
    }
  }

  getVolume() {
    return this.volume
  }

  setCustom(url: string | null) {
    const wasPlaying = this.playing
    this.pause()
    this.customUrl = url
    this.source = url ? 'custom' : 'synth'
    if (wasPlaying && url) {
      void this.play()
    }
  }

  hasCustom() {
    return !!this.customUrl
  }

  getAnalyser(): AnalyserNode | null {
    return this.analyser
  }
}

export const music = new MusicEngine()
