// Global heart-burst event system: any component can spawn floating hearts
// at a screen position; <HeartBurstLayer /> renders them.

export interface BurstDetail {
  x: number
  y: number
  count?: number
  power?: number // px spread
  emojis?: string[]
  size?: number // base font size px
}

export const DEFAULT_HEARTS = ['💗', '💖', '💘', '💕', '✨', '🌸', '🩷']

export function burstHearts(x: number, y: number, opts: Omit<BurstDetail, 'x' | 'y'> = {}) {
  if (typeof window === 'undefined') return
  window.dispatchEvent(new CustomEvent<BurstDetail>('adhwa-burst', { detail: { x, y, ...opts } }))
}

export function burstFromElement(el: HTMLElement | null, opts: Omit<BurstDetail, 'x' | 'y'> = {}) {
  if (!el || typeof window === 'undefined') return
  const r = el.getBoundingClientRect()
  burstHearts(r.left + r.width / 2, r.top + r.height / 2, opts)
}

export function randomBurst(count = 8, opts: Omit<BurstDetail, 'x' | 'y'> = {}) {
  if (typeof window === 'undefined') return
  for (let i = 0; i < count; i++) {
    window.setTimeout(() => {
      burstHearts(
        Math.random() * window.innerWidth,
        window.innerHeight * (0.15 + Math.random() * 0.6),
        { count: 8, ...opts }
      )
    }, i * 260)
  }
}
