// Simple IndexedDB key-value helper for storing photos & audio (dataURL strings).
// localStorage has a ~5MB limit, so media lives here instead.

const DB_NAME = 'adhwa-world'
const STORE = 'kv'

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB not available'))
      return
    }
    const req = indexedDB.open(DB_NAME, 1)
    req.onupgradeneeded = () => {
      const db = req.result
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE)
      }
    }
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => reject(req.error)
  })
}

function withStore<T>(mode: IDBTransactionMode, fn: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return openDB().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const tx = db.transaction(STORE, mode)
        const req = fn(tx.objectStore(STORE))
        req.onsuccess = () => resolve(req.result)
        req.onerror = () => reject(req.error)
        tx.oncomplete = () => db.close()
      })
  )
}

export async function idbGet(key: string): Promise<string | null> {
  try {
    const val = await withStore<string | undefined>('readonly', (s) => s.get(key))
    return val ?? null
  } catch {
    return null
  }
}

export async function idbSet(key: string, value: string): Promise<void> {
  try {
    await withStore('readwrite', (s) => s.put(value, key))
  } catch {
    /* ignore */
  }
}

export async function idbDelete(key: string): Promise<void> {
  try {
    await withStore('readwrite', (s) => s.delete(key))
  } catch {
    /* ignore */
  }
}

export async function idbGetAll(): Promise<Record<string, string>> {
  try {
    const db = await openDB()
    return await new Promise<Record<string, string>>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readonly')
      const store = tx.objectStore(STORE)
      const keysReq = store.getAllKeys()
      const valsReq = store.getAll()
      const out: Record<string, string> = {}
      tx.oncomplete = () => {
        const keys = keysReq.result as IDBValidKey[]
        const vals = valsReq.result as string[]
        keys.forEach((k, i) => {
          out[String(k)] = vals[i]
        })
        db.close()
        resolve(out)
      }
      tx.onerror = () => reject(tx.error)
    })
  } catch {
    return {}
  }
}

export async function idbClear(): Promise<void> {
  try {
    await withStore('readwrite', (s) => s.clear())
  } catch {
    /* ignore */
  }
}
